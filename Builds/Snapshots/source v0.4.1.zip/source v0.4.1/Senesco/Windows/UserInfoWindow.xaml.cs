﻿using System.Windows;
using Senesco.Utility;

namespace Senesco.Windows
{
   /// <summary>
   /// Interaction logic for UserInfoWindow.xaml
   /// </summary>
   public partial class UserInfoWindow : Window
   {
      public UserInfoWindow(Window owner, string userInfoText)
      {
         WindowUtils.ConfigureChildWindow(owner, this);
         InitializeComponent();
         WindowUtils.CenterChildOnParent(owner, this);

         this.userInfoText.Text = userInfoText;
      }

      private void dismissButton_Click(object sender, RoutedEventArgs e)
      {
         this.Close();
      }
   }
}
