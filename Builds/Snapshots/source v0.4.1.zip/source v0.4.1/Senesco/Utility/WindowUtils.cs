﻿using System;
using System.Windows;
using log4net;
using Senesco.Windows;

namespace Senesco.Utility
{
   class WindowUtils
   {
      private static readonly ILog s_log = LogManager.GetLogger(typeof(WindowUtils));

      public static ConfigSettings s_configSettings = new ConfigSettings();

      /// <summary>
      /// For consistent configuration of parent/child windows.
      /// </summary>
      public static void ConfigureChildWindow(Window parent, Window child)
      {
         child.ShowInTaskbar = false;
         child.Owner = parent;
      }

      /// <summary>
      /// Window alignment helper.
      /// </summary>
      public static void CenterChildOnParent(Window parent, Window child)
      {
         if (parent == null || child == null)
            return;

         // Position centered over the userlist.
         child.Left = parent.Left + (parent.Width / 2) - (child.Width / 2);
         child.Top = parent.Top + (parent.Height / 2) - (child.Height / 2);
      }

      /// <summary>
      /// Window alignment helper.
      /// </summary>
      public static void ChildRightSideOfParent(Window parent, Window child)
      {
         if (parent == null || child == null)
            return;

         // Position just off to the right at the same height.
         child.Left = parent.Left + parent.Width + 1;
         child.Top = parent.Top;
      }

      /// <summary>
      /// Restores the last saved window position for this window.
      /// </summary>
      public static Status RestoreWindowPosition(Window window)
      {
         if (window == null)
            return Status.NoResult;

         Type type = window.GetType();

         try
         {
            if (type == typeof(ChatWindow))
            {
               window.Left = s_configSettings.ChatWindowLeft;
               window.Top = s_configSettings.ChatWindowTop;
               window.Width = s_configSettings.ChatWindowWidth;
               window.Height = s_configSettings.ChatWindowHeight;
               return Status.Success;
            }
            else if (type == typeof(UserListWindow))
            {
               window.Left = s_configSettings.UserListWindowLeft;
               window.Top = s_configSettings.UserListWindowTop;
               window.Width = s_configSettings.UserListWindowWidth;
               window.Height = s_configSettings.UserListWindowHeight;
               return Status.Success;
            }
            return Status.Failure;
         }
         catch (Exception e)
         {
            s_log.ErrorFormat("Error restoring window position: {0}", e.Message);
            return Status.Failure;
         }

         //Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
         //config.AppSettings.Settings.Add("ModificationDate", DateTime.Now.ToLongTimeString() + " ");
         //config.AppSettings.Settings[""]
         //config.Save(ConfigurationSaveMode.Modified);
      }

      public static Status SaveWindowPosition(Window window)
      {
         if (window == null)
            return Status.NoResult;

         Type type = window.GetType();

         try
         {
            if (type == typeof(ChatWindow))
            {
               s_configSettings.ChatWindowLeft = window.Left;
               s_configSettings.ChatWindowTop = window.Top;
               s_configSettings.ChatWindowWidth = window.Width;
               s_configSettings.ChatWindowHeight = window.Height;
               s_configSettings.Save();
               return Status.Success;
            }
            else if (type == typeof(UserListWindow))
            {
               s_configSettings.UserListWindowLeft = window.Left;
               s_configSettings.UserListWindowTop = window.Top;
               s_configSettings.UserListWindowWidth = window.Width;
               s_configSettings.UserListWindowHeight = window.Height;
               s_configSettings.Save();
               return Status.Success;
            }
            return Status.Failure;
         }
         catch (Exception e)
         {
            s_log.ErrorFormat("Error restoring window position: {0}", e.Message);
            return Status.Failure;
         }
      }
   }
}
