﻿using System.Configuration;
using log4net;

namespace Senesco.Utility
{
   class ConfigSettings : ApplicationSettingsBase
   {
      private static readonly ILog s_log = LogManager.GetLogger(typeof(ConfigSettings));

      #region Chat Window Coordinates

      [UserScopedSetting()]
      [DefaultSettingValue("20")]
      public double ChatWindowLeft
      {
         get { return (double)this["ChatWindowLeft"]; }
         set { this["ChatWindowLeft"] = (double)value; }
      }
      [UserScopedSetting()]
      [DefaultSettingValue("20")]
      public double ChatWindowTop
      {
         get { return (double)this["ChatWindowTop"]; }
         set { this["ChatWindowTop"] = (double)value; }
      }
      [UserScopedSetting()]
      [DefaultSettingValue("550")]
      public double ChatWindowWidth
      {
         get { return (double)this["ChatWindowWidth"]; }
         set { this["ChatWindowWidth"] = (double)value; }
      }
      [UserScopedSetting()]
      [DefaultSettingValue("350")]
      public double ChatWindowHeight
      {
         get { return (double)this["ChatWindowHeight"]; }
         set { this["ChatWindowHeight"] = (double)value; }
      }

      #endregion

      #region User List Window Coordinates

      [UserScopedSetting()]
      [DefaultSettingValue("572")]
      public double UserListWindowLeft
      {
         get { return (double)this["UserListWindowLeft"]; }
         set { this["UserListWindowLeft"] = (double)value; }
      }
      [UserScopedSetting()]
      [DefaultSettingValue("20")]
      public double UserListWindowTop
      {
         get { return (double)this["UserListWindowTop"]; }
         set { this["UserListWindowTop"] = (double)value; }
      }
      [UserScopedSetting()]
      [DefaultSettingValue("280")]
      public double UserListWindowWidth
      {
         get { return (double)this["UserListWindowWidth"]; }
         set { this["UserListWindowWidth"] = (double)value; }
      }
      [UserScopedSetting()]
      [DefaultSettingValue("350")]
      public double UserListWindowHeight
      {
         get { return (double)this["UserListWindowHeight"]; }
         set { this["UserListWindowHeight"] = (double)value; }
      }

      #endregion
   }
}
