﻿using System;
using System.Collections.Generic;
using log4net;
using Senesco.Transactions;
using Senesco.Utility;
using log4net.Repository;
using log4net.Appender;
using System.IO;

namespace Senesco.Main
{
   public class SenescoController
   {
      #region Fields and Creator

      private static readonly ILog s_log = LogManager.GetLogger(typeof(SenescoController));
      private static readonly ILog s_chatLog = LogManager.GetLogger("ChatLog");

      private Server m_server = null;
      private UserList m_userList = null;

      // Delegates for Transaction handling.
      public delegate void ChatReceivedDelegate(string text);
      public delegate void DisconnectedDelegate();
      public delegate void UserListUpdateDelegate(List<User> addList, List<User> removeList, bool delta);
      public delegate void PrivateMsgDelegate(string sendingNick, string message);
      public delegate void UserInfoDelegate(string userInfo);

      public ChatReceivedDelegate ChatReceived = null;
      public DisconnectedDelegate Disconnected = null;
      public UserListUpdateDelegate UserListUpdate = null;
      public PrivateMsgDelegate PmReceived = null;
      public UserInfoDelegate UserInfoReceived = null;

      public SenescoController()
      { }

      // TODO: Move userlist into the server object (makes more sense organizationally)
      public List<User> UserList
      {
         get
         {
            if (m_userList != null)
               return m_userList.Users;
            return new List<User>();
         }
      }

      #endregion

      #region Connect, Disconnect, Shutdown

      public Status Connect(Server settings)
      {
         if (settings == null)
            return Status.Failure;

         return Connect(settings.ServerName, settings.Address, 
            settings.LoginName, settings.Password,
            settings.Nick, settings.Icon);
      }

      public Status Connect(string name, string address,
                            string username, string password,
                            string nick, int icon)
      {
         if (m_server != null)
            m_server.Disconnect();

         // Configure the Server object for connecting.
         m_server = new Server();
         m_server.ServerName = name;
         m_server.Address = address;

         // Set up the event delegates for this Server connection.
         m_server.ChatReceived = HandleChatReceived;
         m_server.Disconnected = HandleDisconnected;
         m_server.UserListUpdate = HandleUserListUpdate;
         m_server.PmReceived = HandlePmReceived;
         m_server.UserInfoReceived = HandleUserInfoReceived;

         //LocalChatMessage(String.Format("Connecting to '{0}'...", m_server.ServerName));

         // Initiate server connection.
         if (m_server.Connect() == Status.Failure)
         {
            string message = String.Format("Connecting to {0} failed.", address);
            s_log.ErrorFormat(message);
            LocalChatMessage(message);
            return Status.Failure;
         }

         // Send initial transactions.
         m_server.SendTransaction(new Login(username, password, nick, icon));
         m_server.SendTransaction(new GetUserList(null));

         // Send a notice to the chat window to make it clear you have been disconnected.
         LocalChatMessage(String.Format("Connected to '{0}'", m_server.ServerName));

         return Status.Success;
      }

      public void Disconnect()
      {
         // Disconnect from any connected servers.
         if (m_server != null)
         {
            m_server.Disconnect();

            // Send a notice to the chat window to make it clear you have been disconnected.
            LocalChatMessage(String.Format("Disconnected from '{0}'", m_server.ServerName));
         }
      }

      public void Shutdown()
      {
         Disconnect();
      }

      #endregion

      #region Chat System

      /// <summary>
      /// Sends a "local message" to the chat system with some labels and a
      /// timestamp to provide status updates to the user.
      /// </summary>
      /// <param name="message">The message to display.</param>
      private void LocalChatMessage(string message)
      {
         // Include the timestamp by default.
         LocalChatMessage(message, true);
      }

      private void LocalChatMessage(string message, bool includeTimestamp)
      {
         // Format the message.
         HandleChatReceived(String.Format("\n<<< {0} >>>", message), -1, true);

         // Include the timestamp if flagged to.
         if (includeTimestamp)
            HandleChatReceived(String.Format("\n<<< {0} >>>", DateTime.Now.ToString()), -1, true);
      }

      /// <summary>
      /// Sends the given chat string to the connected server.
      /// </summary>
      /// <param name="text">The chat string to process and send.</param>
      /// <param name="cursorIndex">
      /// The index position of the cursor, if available.  Specify -1 otherwise.
      /// </param>
      /// <param name="emote">True if the chat should be sent as an emote.</param>
      /// <returns>
      /// Status.Success if all chats were successfully queued.
      /// Status.NoResult if there was no chat to send, or no newlines were present.
      /// Status.Failure if there was chat to send but queueing failed.
      /// </returns>
      public Status CheckSendChat(string text, int cursorIndex, bool emote)
      {
         if (text.Contains("\n") == false)
         {
            //s_log.Debug("No newline character - not sending chat");
            return Status.NoResult;
         }

         if (m_server == null)
         {
            s_log.ErrorFormat("Not sending chat - not connected to server");
            return Status.Failure;
         }

         s_log.Debug("Newline character found, and connected to a server - sending chat");

         List<string> chats = ProcessChat(text, cursorIndex);

         if (chats == null || chats.Count == 0)
         {
            s_log.Debug("No chats to send.");
            return Status.NoResult;
         }

         // Don't allow multi-line emotes.
         if (chats.Count > 1)
            emote = false;

         // Send each chat in a separate SendChat transaction.
         Status result = Status.NoResult;
         foreach (string chat in chats)
         {
            result = m_server.SendTransaction(new SendChat(chat, null, emote));
            if (result == Status.Failure)
            {
               s_log.ErrorFormat("Sending chat failed: {0}", chat);
               return Status.Failure;
            }
         }
         return result;
      }

      /// <summary>
      /// This method first removes the newline sequence freshly added by the GUI, but
      /// only if the cursorIndex parameter is specified.  The parameter assumes the
      /// index is the position of the cursor AFTER the newline sequence has been added,
      /// which means the newline sequence will span [cursorIndex-2 to cursorIndex-1]
      /// inclusively if it is present.
      /// 
      /// After the newline sequence is surgically removed, the remaining text processing
      /// splits the chat sequence into lines by splitting on the same newline sequence.
      /// 
      /// The point of this complicated method is to allow the user to paste a large block
      /// of text spanning multiple lines while simultaneously making the cursor position
      /// irrelevant when the user presses return to submit the chat.
      /// </summary>
      /// <param name="text">The text to process.</param>
      /// <param name="cursorIndex">The current cursor position, or -1.</param>
      /// <returns>A list of single lines of chat.</returns>
      private List<string> ProcessChat(string text, int cursorIndex)
      {
         try
         {
            // If a non-negative cursor index is given, remove the newline characters just before it.
            if (cursorIndex >= 0)
            {
               // Take two characters before the current cursorIndex.
               string newlineSeq = text.Substring(cursorIndex - 2, 2);
               // If they are a newline sequence, remove only those two characters.
               if (newlineSeq == "\r\n")
                  text = text.Remove(cursorIndex - 2, 2);
            }
         }
         catch
         { }

         // Split up the chat into an array of lines.
         // Each line will generally end with "\r\n" as CR and LF (windows line endings).
         string[] delimiters = new string[1] { "\r\n" };
         string[] rawLines = text.Split(delimiters, StringSplitOptions.None);

         // Remove the newline characters from each line.
         List<string> finalLines = new List<string>();
         foreach (string rawLine in rawLines)
         {
            //string finalLine = rawLine.Replace("\r\n", "");
            string finalLine = rawLine.Trim();
            if (string.IsNullOrEmpty(finalLine) == false)
               finalLines.Add(finalLine);
         }
         return finalLines;
      }

      #endregion

      #region Incoming Transaction Delegates

      public void HandleChatReceived(string chatText, int chatWindow)
      {
         HandleChatReceived(chatText, chatWindow, false);
      }

      public void HandleChatReceived(string chatText, int chatWindow, bool local)
      {
         // Make sure the chat text ends with a newline.
         chatText = String.Format("\n{0}", chatText.Trim());
         
         // If one is set, invoke the view's delegate.
         if (ChatReceived != null)
            ChatReceived(chatText);

         // Add this text to the chat log.
         if (local)
            s_chatLog.Debug(chatText);
         else
            s_chatLog.Info(chatText);
      }

      public void HandleLoginFailed()
      {

      }

      public void HandleDisconnected()
      {
         // TODO: Invoke the view's delegate.
         // This is mainly so the view can update GUI controls.

         // Perform all of the back-end clean-up too.
         Disconnect();
      }

      public void HandleUserListUpdate(List<User> addList, List<User> removeList, bool delta)
      {
         // Update the user list in the model.

         // If this is not a delta, then we're being given a complete list of users in "addList".
         if (delta == false)
         {
            m_userList = new UserList(addList);
         }
         else
         {
            // Otherwise, this IS a delta, so update the list appropriately.
            if (removeList != null && removeList.Count > 0)
            {
               LocalChatMessage(m_userList.FormatUserLeaveMsg(removeList));
               m_userList.RemoveUsers(removeList);
            }
            if (addList != null && addList.Count > 0)
            {
               LocalChatMessage(m_userList.FormatUserChangeMsg(addList));
               m_userList.AddUsers(addList);
            }
         }

         // Invoke the view's delegate to show the update.
         if (UserListUpdate != null)
            UserListUpdate(addList, removeList, delta);
      }

      public void HandleUserInfoReceived(string userInfo)
      {
         if (UserInfoReceived != null)
            UserInfoReceived(userInfo);
      }
      
      public void HandlePmReceived(string sendingNick, string message)
      {
         // Use the PM Received delegate, or if one is not specified print it as a formatted chat.
         if (PmReceived != null)
            PmReceived(sendingNick, message);
         else if (ChatReceived != null)
            ChatReceived(String.Format("<<< {0}: {1} >>>", sendingNick, message));
      }

      #endregion

      #region Bookmark Wrappers

      // Even though the FileUtils class can be accessed directly, the View
      // should generally use the Controller class for every operation.

      public Status AddBookmark(Server server)
      {
         return FileUtils.AddBookmark(server);
      }

      public List<string> GetBookmarkNames()
      {
         return FileUtils.GetBookmarkNames();
      }

      public Server GetBookmark(string serverName)
      {
         return FileUtils.GetBookmark(serverName);
      }

      public string GetAutoConnectBookmark()
      {
         return RegistryUtils.GetAutoConnectBookmark();
      }

      #endregion

      #region User List Interaction

      public void GetUserInfo(User selectedUser)
      {
         if (m_server == null || m_server.Connected == false)
         {
            s_log.ErrorFormat("Cannot get user info: not connected to server.");
            return;
         }
         if (selectedUser == null)
         {
            s_log.ErrorFormat("Cannot get user info: no user specified.");
            return;
         }
         m_server.SendTransaction(new GetUserInfo(selectedUser.UserId));
      }

      public void SendPrivateMessage(User selectedUser, string message)
      {
         if (m_server == null || m_server.Connected == false)
         {
            s_log.ErrorFormat("Cannot send PM: not connected to server.");
            return;
         }
         if (selectedUser == null)
         {
            s_log.ErrorFormat("Cannot send PM: no user specified.");
            return;
         }
         m_server.SendTransaction(new PmSend(selectedUser.UserId, message));
      }

      #endregion

      #region Chat Log Files

      public void OpenChatLog()
      {
         System.Diagnostics.Process.Start(GetLogFilePath("RollingChatLog"));
      }

      public void ShowChatLogs()
      {
         string fullPath = GetLogFilePath("RollingChatLog");
         System.Diagnostics.Process.Start(Path.GetDirectoryName(fullPath));
      }

      private string GetLogFilePath(string appenderName)
      {
         // Get the current log file from log4net.
         // Unfortunately, this returns ALL appenders intsead of just the ones for s_chatLog.
         IAppender[] appenders = s_chatLog.Logger.Repository.GetAppenders();
         if (appenders == null)
         {
            s_log.Error("No appenders found for chat log.");
            return string.Empty;
         }

         // Confirm which appender has the correct type and name.
         foreach (IAppender appender in appenders)
         {
            RollingFileAppender rfa = appender as RollingFileAppender;
            if (rfa == null)
               continue;
            if (rfa.Name != appenderName)
               continue;

            // Return the matching filename.
            s_log.InfoFormat("Launching file: {0}", rfa.File);
            return rfa.File;
         }

         s_log.ErrorFormat("No matching appender found.");
         return string.Empty;
      }

      #endregion

      #region Help Menu

      public static void LaunchWebsite()
      {
         // Launch the website URL.
         //System.Diagnostics.Process.Start("http://rancor.yi.org/Senesco/53cr37/");

         // Launch directly to the changelog embed.
         System.Diagnostics.Process.Start("http://rancor.yi.org/Senesco/53cr37/index.php?file=changelog.txt");
      }

      #endregion
   }
}
