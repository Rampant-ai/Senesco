
Senesco
v. To grow old, to grow aged, to mature, wear out. 

-----------------------------------------------

Who says Hotline is old, aged, matured, or worn out?

...Oh, right.  Everybody.



Future Planned Features
-----------------------
-Sounds.
-Register .sbm with Windows on startup (and/or install).
-Hook up auto-reconnect system.
-Remove bookmarks via GUI.

-Improve user list display (icons, operations, etc).
-Improve chat text display (hyperlinks, etc).
-Add chat-prefix system for command entry (eg. /me says hi).

-Port to win32 console.
-Port to other platforms using Mono.
-Port to other GUI's using Mono by ditching WPF.


Known Issues
------------
-Most GUI operations block since they run in the foreground.
-Return key doesn't register when alt is held down (need to change input style drastically).
-Bookmarks are not encoded, so your password is stored in plaintext (if you know where to look).
-Sizing chat window super small can screw up the division between chat view and chat entry box.


Features That Probably Won't Be Added
-------------------------------------
-News
-Files
-Agreement
-Trackers
