﻿
using System;
using Senesco.Main;
using Senesco.Main.Events;
using System.Text;
using System.Reflection;

namespace Senesco.Console
{
   class Program
   {
      private static SenescoController s_controller = new SenescoController();

      static void Main(string[] args)
      {
         PrintVersion();

         // Subscribe to all of the controller events.
         SubscribeToEvents();

         //TODO: process arguments for immediate server connection

         //Server server1 = s_controller.GetBookmark("Nodesprawl Guest");
         //Server server2 = s_controller.GetBookmark("CMG");
         //s_controller.Connect(server1);

         // Begin monitoring user input.
         InputLoop();
      }

      #region User Input

      private static void InputLoop()
      {
         try
         {
            bool continueLoop = true;
            StringBuilder buffer = new StringBuilder(80);
            while (continueLoop)
            {
               //TODO: switch intercept to true then manually manage the user input
               ConsoleKeyInfo input = System.Console.ReadKey(false);
               if (input.Key == ConsoleKey.Enter)
               {
                  // Submit the finished text and clear the buffer.
                  continueLoop = ProcessInput(buffer.ToString());
                  buffer.Remove(0, buffer.Length);
               }
               else if (input.Key == ConsoleKey.Backspace)
               {
                  if (buffer.Length > 0)
                  {
                     buffer.Remove(buffer.Length - 1, 1);
                     // Wipe out the visible character using space and backspace.
                     Write(" \b");
                  }
               }
               else
               {
                  buffer.Append(input.KeyChar);
               }
            }
         }
         catch (Exception e)
         {
            WriteLine(e.Message);
            WriteLine(e.StackTrace);
         }
      }

      private static bool ProcessInput(string text)
      {
         // Is this input a command?
         string command = GetCommand(text, out text);

         // Handle the various commands, or just submit as chat.
         if (CommandMatches("connect", command) ||
             CommandMatches("server", command))
         {
            // The rest of the command should be the server name to connect to.
            if (s_controller.Connect(s_controller.GetBookmark(text)) == Status.Failure)
               WriteLine("Failed to connect");
         }
         else if (CommandMatches("disconnect", command) ||
                  CommandMatches("bye", command))
         {
            if (s_controller.Disconnect("User Disconnect") == Status.Failure)
               WriteLine("Failed to disconnect");
         }
         else if (CommandMatches("quit", command) ||
                  CommandMatches("exit", command))
         {
            s_controller.Disconnect("User Quit");
            return false;
         }
         else if (CommandMatches("version", command))
         {
            PrintVersion();
         }
         else if (CommandMatches("help", command))
         {
            PrintHelp();
         }
         else if (CommandMatches("who", command))
         {
            // Request user list from server.
            if (s_controller.GetUserList() == Status.Failure)
               WriteLine("Failed to get user list");
         }
         else if (CommandMatches("me", command))
         {
            // Submit text as emote.
            if (s_controller.SendChat(text, true) == Status.Failure)
               WriteLine("Failed to send chat");
         }
         else
         {
            // Submit text as chat.
            if (s_controller.SendChat(text, false) == Status.Failure)
               WriteLine("Failed to send chat");
         }

         return true;
      }

      private static bool CommandMatches(string command, string input)
      {
         return command.Equals(input, StringComparison.OrdinalIgnoreCase);
      }

      private static string GetCommand(string text, out string strippedText)
      {
         // If the text does not start with a command character, it's not a command.
         if (text.StartsWith("/") == false)
         {
            strippedText = text;
            return null;
         }

         // Find the end of the command word, either by delimiter or total string
         // length if there's no text after the command.
         int delimiter = text.IndexOf(" ");
         if (delimiter == -1)
         {
            delimiter = text.Length;
            strippedText = string.Empty;
         }
         else
         {
            // If there's anything after the delimiter character, then copy it as
            // the stripped output.
            if (text.Length > delimiter)
               strippedText = text.Substring(delimiter + 1, (text.Length - 1) - delimiter);
            else
               strippedText = string.Empty;
         }

         return text.Substring(1, delimiter - 1);
      }

      #endregion

      #region Console Text Management

      private static void Write(string text, params object[] args)
      {
         // Delete the current user-display by moving up several lines.
         // Display the new text.
         // Redraw the user-display exactly as it was.

         System.Console.Write(String.Format(text, args));
      }

      private static void WriteLine(string text, params object[] args)
      {
         System.Console.WriteLine(String.Format(text, args));
      }

      #endregion

      #region Event Handling

      static void SubscribeToEvents()
      {
         s_controller.ChatReceived += new EventHandlers.ChatReceivedEventHandler(Event_ChatReceived);
         s_controller.Connected += new EventHandlers.ConnectedEventHandler(Event_Connected);
         s_controller.Disconnected += new EventHandlers.DisconnectedEventHandler(Event_Disconnected);
         s_controller.PmReceived += new EventHandlers.PrivateMsgEventHandler(Event_PmReceived);
         s_controller.ProgressUpdated += new EventHandlers.ProgressUpdatedEventHandler(Event_ProgressUpdated);
         s_controller.UserInfoReceived += new EventHandlers.UserInfoDelegate(Event_UserInfoReceived);
         s_controller.UserListUpdate += new EventHandlers.UserListUpdateEventHandler(Event_UserListUpdate);
      }

      static void Event_UserListUpdate(object sender, UserListUpdateEventArgs e)
      {
         if (e.Delta == true)
         {
            // Report changes if a delta update.
            if (e.AddList != null)
            {
               foreach (User user in e.AddList)
               {
                  WriteLine("*** Join: {0}", user.ToString());
               }
            }
            if (e.RemoveList != null)
            {
               foreach (User user in e.RemoveList)
               {
                  WriteLine("*** Part: {0}", user.ToString());
               }
            }
         }
         else
         {
            // Dump complete userlist.
            if (e.AddList != null)
            {
               WriteLine("---------------------");
               WriteLine("User List:");
               foreach (User user in e.AddList)
               {
                  WriteLine(String.Format("   {0}", user.ToString()));
               }
               WriteLine("---------------------");
            }
         }
      }

      static void Event_UserInfoReceived(object sender, UserInfoEventArgs e)
      {
         WriteLine("---------------------");
         WriteLine("User Details:");
         WriteLine(e.UserInfo.Trim());
         WriteLine("---------------------");
      }

      static void Event_ProgressUpdated(object sender, ProgressUpdatedEventArgs e)
      {
         WriteLine("\"{0}\" at {1}%", e.EventUpdated, e.ProgressPercent);
      }

      static void Event_PmReceived(object sender, PrivateMsgEventArgs e)
      {
         WriteLine("Private Message: ({0}) {1}", e.SendingNick, e.Message.Trim());
      }

      static void Event_Disconnected(object sender, DisconnectedEventArgs e)
      {
         WriteLine("Disconnected!");
      }

      static void Event_Connected(object sender, ConnectedEventArgs e)
      {
         WriteLine("Connected!");
      }

      static void Event_ChatReceived(object sender, ChatReceivedEventArgs e)
      {
         WriteLine(e.Text.Trim());
      }

      static void PrintVersion()
      {
         try
         {
            string version = Assembly.GetExecutingAssembly().GetName().Version.ToString();
            WriteLine(String.Format("Senesco v{0}", version));
         }
         catch
         {
            WriteLine("Senesco (unknown version)");
         }
         WriteLine("Type /help for a list of commands");
      }

      static void PrintHelp()
      {
         WriteLine("Commands:");
         WriteLine("   /connect /server <bookmark name>");
         WriteLine("   /disconnect /bye");
         WriteLine("   /quit /exit");
         WriteLine("   /me <emote text>");
         WriteLine("   /who");
         WriteLine("   /version");
         WriteLine("   /help");
      }

      #endregion
   }
}
