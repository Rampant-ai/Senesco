﻿using System;

namespace Senesco.Main.Events
{
   public class PrivateMsgEventArgs : EventArgs
   {
      private readonly string m_sendingNick;
      private readonly string m_message;

      public string SendingNick
      {
         get { return m_sendingNick; }
      }
      
      public string Message
      {
         get { return m_message; }
      }

      public PrivateMsgEventArgs(string sendingNick, string message)
      {
         m_sendingNick = sendingNick;
         m_message = message;
      }
   }
}
