﻿
namespace Senesco.Transactions.Objects.ObjectData
{
   public abstract class IHotlineObjectData
   {
      public abstract byte[] GetBytes();
   }
}
