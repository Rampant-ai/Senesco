﻿
using Senesco.Transactions.Objects.ObjectData;
using Senesco.Utility;

namespace Senesco.Transactions.Objects
{
   class UserStatus : HotlineObject
   {
      public Number Value;

      /// <summary>
      /// Default creator for the ObjectFactory to use.
      /// </summary>
      public UserStatus()
      { }

      public UserStatus(int userStatus)
      {
         Value = new Number(userStatus);
         this.ObjectDataList.Add(Value);
      }

      internal override void ParseBytes(byte[] objectData)
      {
         int index = 0;
         int userStatus = DataUtils.ReadNumber(objectData, ref index);

         Value = new Number(userStatus);
         this.ObjectDataList.Add(Value);
      }
   }
}
