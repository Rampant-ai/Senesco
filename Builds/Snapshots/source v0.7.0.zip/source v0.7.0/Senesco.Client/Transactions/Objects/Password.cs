﻿
using Senesco.Transactions.Objects.ObjectData;
using Senesco.Utility;

namespace Senesco.Transactions.Objects
{
   class Password : HotlineObject
   {
      public EncodedString Value;

      /// <summary>
      /// Default creator for the ObjectFactory to use.
      /// </summary>
      public Password()
      { }

      public Password(string password)
      {
         Value = new EncodedString(password);
         this.ObjectDataList.Add(Value);
      }

      internal override void ParseBytes(byte[] objectData)
      {
         int index = 0;
         string password = DataUtils.ReadEncodedString(objectData, ref index, objectData.Length);

         Value = new EncodedString(password);
         this.ObjectDataList.Add(Value);
      }
   }
}
