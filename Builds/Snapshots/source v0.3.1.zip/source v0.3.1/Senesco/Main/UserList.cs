﻿using System;
using System.Collections.Generic;
using System.Text;
using log4net;

namespace Senesco.Main
{
   class UserList
   {
      #region Fields and Creator

      private static readonly ILog s_log = LogManager.GetLogger(typeof(UserList));

      private Dictionary<int, User> m_userLookup = new Dictionary<int, User>();

      public List<User> Users
      {
         get
         {
            s_log.Debug("UserList: Getting Users property");
            List<User> returnList = new List<User>();
            if (m_userLookup != null)
            {
               foreach (KeyValuePair<int,User> kvp in m_userLookup)
                  returnList.Add(kvp.Value);
            }
            return returnList;
         }
      }

      public UserList(List<User> userList)
      {
         if (userList == null)
            return;

         foreach (User user in userList)
            m_userLookup.Add(user.UserId, user);
      }

      #endregion

      #region Add User

      public Status AddUsers(List<User> usersToAdd)
      {
         if (usersToAdd == null)
            return Status.NoResult;

         // Process the whole list, but keep track of if any failed.
         bool fail = false;
         foreach (User user in usersToAdd)
         {
            if (AddUser(user) == Status.Failure)
               fail = true;
         }

         if (fail)
            return Status.Failure;
         else
            return Status.Success;
      }

      public Status AddUser(User user)
      {
         if (user == null)
         {
            s_log.ErrorFormat("UserList.AddUser(): User is null.");
            return Status.Failure;
         }

         try
         {
            m_userLookup.Add(user.UserId, user);
            return Status.Success;
         }
         catch (ArgumentException e)
         {
            s_log.ErrorFormat("UserID {0} already in UserLst ({1})", user.UserId, e.Message);
            m_userLookup[user.UserId] = user;
            return Status.NoResult;
         }
         catch (Exception e)
         {
            s_log.ErrorFormat("Exception adding User {0}: {1}", user.ToString(), e.Message);
            return Status.Failure;
         }
      }

      #endregion

      #region Remove User

      public Status RemoveUsers(List<User> usersToRemove)
      {
         if (usersToRemove == null)
            return Status.NoResult;

         // Process the whole list, but keep track of if any failed.
         bool fail = false;
         foreach (User user in usersToRemove)
         {
            if (RemoveUser(user) == Status.Failure)
               fail = true;
         }

         if (fail)
            return Status.Failure;
         else
            return Status.Success;
      }

      public Status RemoveUser(User user)
      {
         if (user == null)
         {
            s_log.ErrorFormat("UserList.RemoveUser(): User is null.");
            return Status.Failure;
         }
         
         if (m_userLookup.Remove(user.UserId) == false)
         {
            s_log.ErrorFormat("UserList.RemoveUser(): User not found.");
            return Status.Failure;
         }

         return Status.Success;
      }

      #endregion

      #region Message Formatting

      public string FormatUserChangeMsg(List<User> addList)
      {
         if (addList == null)
            return String.Empty;

         // Start the message.
         StringBuilder sb = new StringBuilder();
         sb.Append("Join/Update: ");

         // Loop over all users in the list (usually just one).
         bool first = true;
         foreach (User user in addList)
         {
            // This is generally called from a Join or Update message.  In either case, we
            // want to cite the new Nick which will be in the parameter list rather than the
            // local list of users in this instance.  If no nick is available for whatever
            // reason, look up the UserId in this instance instead.  (Maybe an icon change...)
            
            // Get the User object to cite.
            User target = null;
            // If the input username is empty, use the one from the current userlist.
            if (String.IsNullOrEmpty(user.Username))
               target = m_userLookup[user.UserId];
            else
               target = user;

            if (target != null)
            {
               if (first == true)
                  first = false;
               else
                  sb.Append(", ");

               //sb.Append(target.Username);
               sb.Append(target.ToString());
            }
         }

         return sb.ToString();
      }

      public string FormatUserLeaveMsg(List<User> removeList)
      {
         if (removeList == null)
            return String.Empty;

         // Start the message.
         StringBuilder sb = new StringBuilder();
         sb.Append("Part: ");

         // Loop over all users in the list (usually just one).
         bool first = true;
         foreach (User user in removeList)
         {
            // This is generally called from a Leave message.
            // Typically that can be assumed to only include the UserId.

            // Get the User object to cite.
            User target = null;
            // If the input username is empty, use the one from the current userlist.
            if (String.IsNullOrEmpty(user.Username))
               target = m_userLookup[user.UserId];
            else
               target = user;

            if (target != null)
            {
               if (first == true)
                  first = false;
               else
                  sb.Append(", ");

               //sb.Append(target.Username);
               sb.Append(target.ToString());
            }
         }

         return sb.ToString();
      }

      #endregion
   }
}
