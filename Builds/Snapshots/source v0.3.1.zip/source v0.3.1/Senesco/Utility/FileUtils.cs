﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using log4net;
using Senesco.Main;

namespace Senesco.Utility
{
   class FileUtils
   {
      private static readonly ILog s_log = LogManager.GetLogger(typeof(FileUtils));

      private static string s_bookmarkDirectory = string.Empty;
      private const string s_bookmarkExtension = ".sbm";

      public static Status AddBookmark(Server server)
      {
         if (server == null)
            return Status.Failure;

         try
         {
            s_log.InfoFormat("Saving bookmark for server '{0}'", server.ServerName);

            string filename = server.ServerName + s_bookmarkExtension;
            string fullPath = Path.Combine(GetBookmarkDirectory(), filename);
            using (FileStream fs = new FileStream(fullPath, FileMode.Create))
            {
               BinaryFormatter serializer = new BinaryFormatter();
               serializer.Serialize(fs, server);
            }
            return Status.Success;
         }
         catch (Exception e)
         {
            s_log.ErrorFormat("Error saving bookmark: {0}", e.Message);
            return Status.Failure;
         }
      }

      public static Server GetBookmark(string serverName)
      {
         try
         {
            if (String.IsNullOrEmpty(serverName))
            {
               s_log.ErrorFormat("Tried to retrieve bookmark for empty server name.");
               return null;
            }

            s_log.InfoFormat("Retrieving bookmark for server '{0}'", serverName);

            // Construct full path to the bookmark file.
            string fullPath = Path.Combine(GetBookmarkDirectory(), serverName + s_bookmarkExtension);

            // Open the file and deserialize the Server object.
            using (FileStream fs = new FileStream(fullPath, FileMode.Open))
            {
               BinaryFormatter serializer = new BinaryFormatter();
               return (Server)serializer.Deserialize(fs);
            }
         }
         catch (Exception e)
         {
            s_log.ErrorFormat("Error reading bookmark: {0}", e.Message);
            return null;
         }
      }

      public static List<string> GetBookmarkNames()
      {
         try
         {
            s_log.InfoFormat("Listing all bookmarks");

            // List to be returned.
            List<string> bookmarkNames = new List<string>();

            // Filename mask search parameter, wildcard plus our file extension.
            string bookmarkPath = GetBookmarkDirectory();
            string bookmarkMask = "*" + s_bookmarkExtension;

            // Search for the matching filenames.
            string[] foundFiles = Directory.GetFiles(bookmarkPath, bookmarkMask);

            if (foundFiles == null || foundFiles.Length == 0)
            {
               s_log.InfoFormat("No bookmarks found in: {0}", bookmarkPath);
               return null;
            }

            // Use the filenames rather than the serialized name within the file.
            // The user could rename the files, of course, and that's okay since all we have
            // to do is assume that a "connect via bookmark" command is specifying the bookmark
            // filename.
            foreach (string fullPath in foundFiles)
               bookmarkNames.Add(Path.GetFileNameWithoutExtension(fullPath));

            return bookmarkNames;
         }
         catch (Exception e)
         {
            s_log.ErrorFormat("Error listing bookmark names: {0}", e.Message);
            return null;
         }
      }

      private static string GetBookmarkDirectory()
      {
         string dir = Path.Combine("%APPDATA%", Path.Combine("Senesco", "Bookmarks"));
         dir  = Environment.ExpandEnvironmentVariables(dir);
         if (Directory.Exists(dir) == false)
            Directory.CreateDirectory(dir);
         return dir;
      }
   }
}
