﻿using System.Collections.Generic;
using System.Windows;
using Senesco.Main;

namespace Senesco.Windows
{
   /// <summary>
   /// Interaction logic for UserListWindow.xaml
   /// </summary>
   public partial class UserListWindow : Window
   {
      private SenescoController m_controller;

      public UserListWindow(SenescoController controller)
      {
         InitializeComponent();
         m_controller = controller;
         RefreshUserList();
      }

      internal Status RefreshUserList()
      {
         // Get the list of users from the model.
         List<User> userList;

         if (m_controller == null)
            return Status.Failure;
         
         userList = m_controller.UserList;

         if (userList == null || userList.Count == 0)
            return Status.Failure;

         // Clear the GUI list.
         usersListBox.Items.Clear();

         // Add a row for each user in the userList.
         foreach (User user in userList)
            usersListBox.Items.Add(user.ToString());

         return Status.Success;
      }
   }
}
