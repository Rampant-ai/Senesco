﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using log4net;
using Senesco.Utility;
using System.Windows.Input;
using Senesco.Main;

namespace Senesco.Windows
{
   /// <summary>
   /// Interaction logic for ChatWindow.xaml
   /// </summary>
   public partial class ChatWindow : Window
   {
      private static readonly ILog s_log = LogManager.GetLogger(typeof(ChatWindow));

      private SenescoController m_controller = null;

      private UserListWindow m_userListWindow = null;

      // GUI delegate definitions.
      public delegate void ChatDelegate(string text);
      public delegate void NoParamDelegate();
      public delegate void UserListDelegate(List<User> addList, List<User> removeList, bool delta);

      public ChatWindow()
      {
         Log.InitLogging();

         InitializeComponent();
         
         m_controller = new SenescoController();
         m_controller.ChatReceived = chatReceived;
         m_controller.Disconnected = disconnected;
         m_controller.UserListUpdate = userListUpdate;
         SetWindowTitle(null);

         UpdateBookmarks();
      }

      private void Window_Closed(object sender, EventArgs e)
      {
         Exit();
      }

      private void exitMenu_Click(object sender, RoutedEventArgs e)
      {
         Exit();
      }

      private void Exit()
      {
         m_controller.Shutdown();
         if (Application.Current != null)
            Application.Current.Shutdown();
         Environment.Exit(0);
      }

      void SetWindowTitle(string serverName)
      {
         // If empty name given, just "Senesco".
         if (string.IsNullOrEmpty(serverName))
            this.Title = "Senesco";
         // Otherwise, suffix the server name.
         else
            this.Title = string.Format("Senesco: {0}", serverName);
      }

      public void UpdateBookmarks()
      {
         // Get the full list of bookmark names from the controller.
         List<string> bookmarkNames = m_controller.GetBookmarkNames();

         // Clear the old list of bookmarks.
         s_log.InfoFormat("Clearing old bookmarks from root MenuItem {0}", connectRecent.Name);
         connectRecent.Items.Clear();

         // If the list is no good, bail out.
         if (bookmarkNames == null)
         {
            connectRecent.IsEnabled = false;
            return;
         }

         // Create each bookmark as a new submenu item.
         s_log.InfoFormat("Updating {0} with new bookmarks", connectRecent.Name);
         int i = 1;
         foreach (string bookmarkName in bookmarkNames)
         {
            MenuItem mi = new MenuItem();
            mi.Name = String.Format("bookmark{0}", i++);
            mi.Header = bookmarkName;
            mi.Click += bookmark_Click;
            connectRecent.Items.Add(mi);
         }
         connectRecent.IsEnabled = true;
      }

      #region Chat

      private void chatEntry_TextChanged(object sender, TextChangedEventArgs e)
      {
         TextBox textBox = sender as TextBox;

         if (e.Changes.Count == 0)
            return;

         // Is the keyboard modifier for emote being held down?
         bool emote = Keyboard.IsKeyDown(Key.LeftAlt);

         // Get the latest cursor position.
         //int cursor = -1;
         //foreach (TextChange change in e.Changes)
         //   cursor = change.Offset;

         // Try to send the text.  If that was successful, clear the text box.
         if (m_controller.CheckSendChat(textBox.Text, textBox.CaretIndex, emote) == Status.Success)
            this.chatEntry.Text = string.Empty;
      }

      private void chatReceived(string text)
      {
         Dispatcher.Invoke(new ChatDelegate(chatReceivedDelegate), text);
      }

      private void chatReceivedDelegate(string text)
      {
         chatBox.Text += text;

         // If the user is at or lower than 80% of the total scrollback, that's
         // pretty near the bottom so keep the chat scrolled all the way down.
         // This is how we achieve auto-scroll while still allowing the user to
         // scroll up while chat may be actively ongoing.
         if (chatScroll.VerticalOffset >= (0.8 * chatScroll.ScrollableHeight))
            chatScroll.ScrollToBottom();
      }

      #endregion

      #region Connection Controls

      private void InitiateConnect(Server server)
      {
         // Connect using the settings from the other window.
         Status connect = m_controller.Connect(server);

         // If connected successfully, update the window title with the server name.
         if (connect == Status.Success)
         {
            this.chatEntry.IsEnabled = true;
            SetWindowTitle(server.ServerName);
         }
      }

      private void bookmark_Click(object sender, RoutedEventArgs e)
      {
         MenuItem bookmarkItem = sender as MenuItem;
         if (bookmarkItem == null)
         {
            s_log.ErrorFormat("Bad sender for bookmark_Click()!");
            return;
         }

         s_log.InfoFormat("Bookmark '{0}' was clicked from menu.", bookmarkItem.Header);

         Server server = m_controller.GetBookmark(bookmarkItem.Header as string);

         InitiateConnect(server);
      }

      private void connectDialog_Click(object sender, RoutedEventArgs e)
      {
         // Display new connection window.
         ConnectWindow connectWindow = new ConnectWindow(m_controller, this);
         connectWindow.ShowDialog();

         // If the window did not configure a server, do nothing.
         if (connectWindow.ConfiguredServer == null)
         {
            s_log.InfoFormat("Connection window did not configure a server.");
            return;
         }

         InitiateConnect(connectWindow.ConfiguredServer);
      }

      private void disconnectMenu_Click(object sender, RoutedEventArgs e)
      {
         m_controller.Disconnect();
         SetWindowTitle(null);
         disconnectedEvent();
      }

      private void disconnected()
      {
         Dispatcher.Invoke(new NoParamDelegate(disconnectedEvent));
      }

      private void disconnectedEvent()
      {
         //TODO: Disable the "Disconnect" menu option since no longer connected.
         // other gui changes when becoming disconnected?
      }

      #endregion

      #region User Options

      private void userSettingsMenu_Click(object sender, RoutedEventArgs e)
      {
         // Bring up user settings dialog.
      }
      
      #endregion

      #region User List

      private void userListUpdate(List<User> addList, List<User> removeList, bool delta)
      {
         Dispatcher.Invoke(new UserListDelegate(userListUpdateDelegate), addList, removeList, delta);
      }

      private void userListUpdateDelegate(List<User> addList, List<User> removeList, bool delta)
      {
         // Print the userlist change to the chat window.


         // Open a UserListWindow if one is not already opened.
         if (m_userListWindow == null)
         {
            m_userListWindow = new UserListWindow(m_controller);
            m_userListWindow.ShowInTaskbar = false;
            m_userListWindow.Owner = this;
            m_userListWindow.Show();
         }

         m_userListWindow.RefreshUserList();
      }

      #endregion
   }
}
