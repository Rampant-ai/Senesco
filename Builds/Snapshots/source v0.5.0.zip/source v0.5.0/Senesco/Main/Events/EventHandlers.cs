﻿
namespace Senesco.Main.Events
{
   public class EventHandlers
   {
      public delegate void ChatReceivedEventHandler(object sender, ChatReceivedEventArgs e);
      public delegate void DisconnectedEventHandler(object sender, DisconnectedEventArgs e);
      public delegate void UserListUpdateEventHandler(object sender, UserListUpdateEventArgs e);
      public delegate void PrivateMsgEventHandler(object sender, PrivateMsgEventArgs e);
      public delegate void UserInfoDelegate(object sender, UserInfoEventArgs e);
   }
}
