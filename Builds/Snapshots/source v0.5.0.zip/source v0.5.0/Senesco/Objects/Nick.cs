﻿using Senesco.ObjectData;
using Senesco.Utility;

namespace Senesco.Objects
{
   class Nick : HotlineObject
   {
      public NormalString Value;

      /// <summary>
      /// Default creator for the ObjectFactory to use.
      /// </summary>
      public Nick()
      { }

      public Nick(string nick)
      {
         Value = new NormalString(nick);
         this.ObjectDataList.Add(Value);
      }

      internal override void ParseBytes(byte[] objectData)
      {
         int index = 0;
         string nick = DataUtils.ReadString(objectData, ref index, objectData.Length);

         Value = new NormalString(nick);
         this.ObjectDataList.Add(Value);
      }
   }
}
