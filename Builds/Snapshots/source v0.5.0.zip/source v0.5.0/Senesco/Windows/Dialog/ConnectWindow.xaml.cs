﻿using System;
using System.Windows;
using log4net;
using Senesco.Main;
using Senesco.Utility;
using Senesco.Windows.Main;

namespace Senesco.Windows.Dialog
{
   /// <summary>
   /// Interaction logic for ConnectWindow.xaml
   /// </summary>
   public partial class ConnectWindow : Window
   {
      private static readonly ILog s_log = LogManager.GetLogger(typeof(ConnectWindow));

      private SenescoController m_controller = null;

      public Server ConfiguredServer = null;

      public ConnectWindow(Window owner, SenescoController controller)
      {
         WindowUtils.ConfigureChildWindow(owner, this);
         InitializeComponent();
         WindowUtils.CenterChildOnParent(owner, this);

         m_controller = controller;
      }

      private void cancelButton_Click(object sender, RoutedEventArgs e)
      {
         this.ConfiguredServer = null;
         this.Close();
      }

      private void connectButton_Click(object sender, RoutedEventArgs e)
      {
         // Persist the settings and close the window.
         this.ConfiguredServer = MakeServerFromControls();
         this.Close();
      }

      private void saveButton_Click(object sender, RoutedEventArgs e)
      {
         m_controller.AddBookmark(MakeServerFromControls());

         // Update the parent window's list of bookmarks.
         ChatWindow chatWindow = this.Owner as ChatWindow;
         if (chatWindow != null)
            chatWindow.UpdateBookmarks();
      }

      private Server MakeServerFromControls()
      {
         try
         {
            Server server = new Server();

            server.ServerName = this.serverName.Text;
            server.Address = this.addressText.Text;
            server.Nick = this.nickText.Text;
            server.Icon = 31337;
            server.LoginName = this.usernameText.Text;
            server.Password = this.passwordText.Password;

            return server;
         }
         catch (Exception e)
         {
            s_log.ErrorFormat("Exception setting values from window: {0}", e.Message);
            return null;
         }
      }
   }
}
