﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Threading;
using log4net;
using Senesco.Main;
using Senesco.Utility;
using Senesco.Windows.Config;
using Senesco.Windows.Dialog;
using Senesco.Main.Events;

namespace Senesco.Windows.Main
{
   /// <summary>
   /// Interaction logic for ChatWindow.xaml
   /// </summary>
   public partial class ChatWindow : Window
   {
      private static readonly ILog s_log = LogManager.GetLogger(typeof(ChatWindow));

      private SenescoController m_controller = null;
      private UserListWindow m_userListWindow = null;

      // GUI delegate definitions.
      public delegate void ChatDelegate(string text);
      public delegate void NoParamDelegate();
      public delegate void UserListDelegate(List<User> addList, List<User> removeList, bool delta);
      public delegate void ServerDelegate(Server server);
      public delegate void OneStringDelegate(string str1);
      public delegate void TwoStringDelegate(string str1, string str2);

      public ChatWindow()
      {
         // Initialize logging system.
         Log.InitLogging();

         // Start up this window.
         InitializeComponent();
         
         // Restore window position.
         WindowUtils.RestoreWindowPosition(this);

         // Create and initialize the controller for all the internal logic.
         m_controller = new SenescoController();
         m_controller.ChatReceived += chatReceived;
         m_controller.Disconnected += disconnected;
         m_controller.UserListUpdate += userListUpdate;
         m_controller.PmReceived += pmReceived;
         m_controller.UserInfoReceived += userInfoReceived;

         // Clear the window title initially.
         SetWindowTitle(null);

         // Synchronize the bookmark menu with the current bookmark files.
         UpdateBookmarks();

         // Process the command-line arguments.
         ProcessStartup();
      }

      private void ProcessStartup()
      {
         s_log.InfoFormat("Processing startup events.");

         try
         {
            string[] startupArgs = (string[])Application.Current.Properties["StartupArgs"];

            // Do nothing if no arguments.
            if (startupArgs == null || startupArgs.Length == 0)
               return;

            // Dump arguments if debug logging is enabled.
            if (s_log.IsDebugEnabled)
            {
               for (int i = 0; i < startupArgs.Length; i++)
                  s_log.DebugFormat("{0}: {1}", i, startupArgs[i]);
            }

            // Try to parse the first object as a bookmark.  Returns null upon failure.
            Server server = FileUtils.GetBookmark(new FileInfo(startupArgs[0]));

            // Connect to that server.
            if (server != null)
               InitiateConnect(server);
         }
         catch (Exception e)
         {
            s_log.ErrorFormat("Exception processing startup events: {0}", e.Message);
         }
      }

      private void Exit()
      {
         m_controller.Shutdown();
         if (Application.Current != null)
            Application.Current.Shutdown();
         Environment.Exit(0);
      }

      #region Window Management

      private void SetWindowTitle(string serverName)
      {
         // If empty name given, just "Senesco".
         if (string.IsNullOrEmpty(serverName))
            this.Title = "Senesco";
         // Otherwise, suffix the server name.
         else
            this.Title = string.Format("Senesco: {0}", serverName);
      }

      private void Quit_Event(object sender, EventArgs e)
      {
         Exit();
      }

      private void Window_SizeChanged(object sender, SizeChangedEventArgs e)
      {
         WindowUtils.SaveWindowPosition(this);
      }

      private void Window_LocationChanged(object sender, System.EventArgs e)
      {
         WindowUtils.SaveWindowPosition(this);
      }

      #endregion

      #region Bookmarks

      /// <summary>
      /// This method updates the bookmark menus.  Currently, there are two separate menus.
      /// One is for a quick-connect list, and the other is for picking which bookmark to use
      /// to use for the auto-login feature.
      /// </summary>
      public void UpdateBookmarks()
      {
         // Get the full list of bookmark names from the controller.
         List<string> bookmarkNames = m_controller.GetBookmarkNames();
         string autoConnectBookmark = m_controller.GetAutoConnectBookmark();

         // Clear the old list of bookmarks.
         s_log.InfoFormat("Clearing old bookmarks from root MenuItem {0}", connectRecent.Name);
         connectRecent.Items.Clear();
         autoConnect.Items.Clear();

         // If the list is no good or empty, bail out.
         if (bookmarkNames == null || bookmarkNames.Count == 0)
         {
            connectRecent.IsEnabled = false;
            autoConnect.IsEnabled = false;
            return;
         }

         // Create each bookmark as a new submenu item.
         s_log.InfoFormat("Updating {0} and {1} with bookmarks", connectRecent.Name, autoConnect.Name);
         int i = 1;
         foreach (string bookmarkName in bookmarkNames)
         {
            MenuItem mi = new MenuItem();
            mi.Name = String.Format("bookmark{0}", i);
            mi.Header = bookmarkName;
            mi.Click += bookmark_Click;
            connectRecent.Items.Add(mi);

            MenuItem ac = new MenuItem();
            ac.Name = String.Format("autoconnect{0}", i);
            ac.Header = bookmarkName;
            ac.Click += autoConnect_Click;
            ac.IsCheckable = true;
            ac.IsChecked = (autoConnectBookmark == bookmarkName); // Check the one that's currently set.
            autoConnect.Items.Add(ac);

            i++;
         }

         // Enable both root menus so they're not disabled!
         connectRecent.IsEnabled = true;
         autoConnect.IsEnabled = true;
      }

      private void autoConnect_Click(object sender, RoutedEventArgs e)
      {
         // Change the auto-connect bookmark to this one (if the selection has changed).
         MenuItem selected = sender as MenuItem;
         if (selected == null)
            return;
         string selectedBookmark = selected.Header as string;

         // If the user clicked the one that's already checked, then remove the auto-connect.
         if (selected.IsChecked == false)
            RegistryUtils.RemoveAutoConnectBookmark();
         else
         {
            // Set the user's new selection in the registry.
            RegistryUtils.SetAutoConnectBookmark(selectedBookmark);

            // Update the checks to reflect the new selection (like radio buttons).
            foreach (MenuItem mi in autoConnect.Items)
               mi.IsChecked = (selectedBookmark == mi.Header as string);
         }
      }

      #endregion

      #region Chat

      private void chatEntry_TextChanged(object sender, TextChangedEventArgs e)
      {
         TextBox textBox = sender as TextBox;

         if (e.Changes.Count == 0)
            return;

         // Is the keyboard modifier for emote being held down?
         bool emote = Keyboard.IsKeyDown(Key.LeftAlt);

         // Get the latest cursor position.
         //int cursor = -1;
         //foreach (TextChange change in e.Changes)
         //   cursor = change.Offset;

         // Try to send the text.  If that was successful, clear the text box.
         if (m_controller.CheckSendChat(textBox.Text, textBox.CaretIndex, emote) == Status.Success)
            this.chatEntry.Text = string.Empty;
      }

      private void chatReceived(object sender, ChatReceivedEventArgs e)
      {
         if (e != null)
            Dispatcher.Invoke(new ChatDelegate(chatReceivedDelegate), e.Text);
      }

      private void chatReceivedDelegate(string text)
      {
         //if (chatBox.Text.IsEmpty())
         //  chatBox.Text += text.Trim();
         //else
         //  chatBox.Text += text;

         //if (chatBox.Document.Blocks.FirstBlock.Base == 1)
         //if (chatBox.Document == null)
         //{
         //   chatBox.Document = new FlowDocument();
         //   text = text.Trim();
         //}

         // Make sure only one thread at a time adds text.
         lock (chatBox)
         {
            chatBox.AppendText(text);

            // If the user is at or lower than 80% of the total scrollback, that's
            // pretty near the bottom so keep the chat scrolled all the way down.
            // This is how we achieve auto-scroll while still allowing the user to
            // scroll up while chat may be actively ongoing.
            if (chatScroll.VerticalOffset >= (0.8 * chatScroll.ScrollableHeight))
               chatScroll.ScrollToBottom();
         }
      }

      #endregion

      #region Chat Logs

      private void openChatLogMenu_Click(object sender, RoutedEventArgs e)
      {
         m_controller.OpenChatLog();
      }

      private void showChatLogFilesMenu_Click(object sender, RoutedEventArgs e)
      {
         m_controller.ShowChatLogs();
      }

      #endregion

      #region User Info

      private void userInfoReceived(object sender, UserInfoEventArgs e)
      {
         if (e != null)
            Dispatcher.Invoke(new OneStringDelegate(userInfoReceivedDelegate), e.UserInfo);
      }

      private void userInfoReceivedDelegate(string userInfo)
      {
         UserInfoWindow userInfoWindow = new UserInfoWindow(this, userInfo);
         userInfoWindow.Show();
      }

      #endregion

      #region Private Message

      private void pmReceived(object sender, PrivateMsgEventArgs e)
      {
         if (e != null)
            Dispatcher.Invoke(new TwoStringDelegate(pmReceivedDelegate), e.SendingNick, e.Message);
      }

      private void pmReceivedDelegate(string sendingNick, string message)
      {
         PmReceiveWindow pmWindow = new PmReceiveWindow(this, sendingNick, message);
         pmWindow.Show();
      }

      #endregion

      #region Connection Controls

      private void InitiateConnect(Server server)
      {
         Dispatcher.Invoke(new ServerDelegate(InitiateConnectDelegate), server);
      }

      private void InitiateConnectDelegate(Server server)
      {
         if (server != null)
            SetWindowTitle(String.Format("Connecting to '{0}'...", server.ServerName));

         // Connect using the settings from the other window.
         Status connect = m_controller.Connect(server);

         // If connected successfully, update the window title with the server name.
         if (connect == Status.Success)
         {
            this.chatEntry.IsEnabled = true;
            SetWindowTitle(server.ServerName);
         }
      }

      private void bookmark_Click(object sender, RoutedEventArgs e)
      {
         MenuItem bookmarkItem = sender as MenuItem;
         if (bookmarkItem == null)
         {
            s_log.ErrorFormat("Bad sender for bookmark_Click()!");
            return;
         }

         s_log.InfoFormat("Bookmark '{0}' was clicked from menu.", bookmarkItem.Header);

         Server server = m_controller.GetBookmark(bookmarkItem.Header as string);

         InitiateConnect(server);
      }

      private void connectDialog_Click(object sender, RoutedEventArgs e)
      {
         // Display new connection window.
         ConnectWindow connectWindow = new ConnectWindow(this, m_controller);
         connectWindow.ShowDialog();

         // If the window did not configure a server, do nothing.
         if (connectWindow.ConfiguredServer == null)
         {
            s_log.InfoFormat("Connection window did not configure a server.");
            return;
         }

         InitiateConnect(connectWindow.ConfiguredServer);
      }

      private void disconnectMenu_Click(object sender, RoutedEventArgs e)
      {
         disconnectedEvent();
      }

      private void disconnected(object sender, EventArgs e)
      {
         Dispatcher.Invoke(new NoParamDelegate(disconnectedEvent));
      }

      private void disconnectedEvent()
      {
         SetWindowTitle(null);
         m_controller.Disconnect("User Quit.");
         m_userListWindow.ClearUserList();
         //TODO: Disable the "Disconnect" menu option since no longer connected.
         //TODO: Other gui changes when becoming disconnected?
      }

      #endregion

      #region Config Menu

      private void userConfigMenu_Click(object sender, RoutedEventArgs e)
      {
         // Display user config dialog.
      }

      private void soundConfigMenu_Click(object sender, RoutedEventArgs e)
      {
         // Display sound config dialog.
         SoundsConfig config = new SoundsConfig(this, m_controller);
         config.ShowDialog();
      }
      
      #endregion

      #region User List

      private void userListUpdate(object sender, UserListUpdateEventArgs e)
      {
         if (e != null)
            Dispatcher.Invoke(new UserListDelegate(userListUpdateDelegate), e.AddList, e.RemoveList, e.Delta);
      }

      private void userListUpdateDelegate(List<User> addList, List<User> removeList, bool delta)
      {
         // Print the userlist change to the chat window.


         // Open a UserListWindow if one is not already opened.
         if (m_userListWindow == null)
         {
            m_userListWindow = new UserListWindow(this, m_controller);
            m_userListWindow.Show();
         }
      }

      #endregion

      #region Help Menu

      private void aboutMenu_Click(object sender, RoutedEventArgs e)
      {
         // Show the About window.
      }

      private void websiteMenu_Click(object sender, RoutedEventArgs e)
      {
         Dispatcher.Invoke(new NoParamDelegate(launchWebsiteEvent));
      }

      private void launchWebsiteEvent()
      {
         SenescoController.LaunchWebsite();
      }

      #endregion
   }
}
