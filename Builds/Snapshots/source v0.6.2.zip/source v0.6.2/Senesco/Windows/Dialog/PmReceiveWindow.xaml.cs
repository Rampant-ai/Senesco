﻿using System;
using System.Windows;
using System.Windows.Input;
using Senesco.Utility;

namespace Senesco.Windows.Dialog
{
   /// <summary>
   /// Interaction logic for PmReceiveWindow.xaml
   /// </summary>
   public partial class PmReceiveWindow : Window
   {
      public PmReceiveWindow(Window owner, string sendingNick, string message)
      {
         WindowUtils.ConfigureChildWindow(owner, this);
         InitializeComponent();
         WindowUtils.CenterChildOnParent(owner, this);

         m_senderLabel.Content = String.Format("Sender: {0}", sendingNick);
         m_pmText.AppendText(message);
      }

      private void PositionWindow(Window parent)
      {
         if (parent == null)
            return;

         // Position centered over the userlist.
         this.Left = parent.Left + (parent.Width / 2) - (this.Width / 2);
         this.Top = parent.Top + (parent.Height / 2) - (this.Height / 2);
      }

      private void Window_KeyDown(object sender, KeyEventArgs e)
      {
         // Close the window immediately if Escape is pressed.
         if (Keyboard.IsKeyDown(Key.Escape))
            this.Close();
      }

      private void DismissButton_Click(object sender, RoutedEventArgs e)
      {
         this.Close();
      }
   }
}
