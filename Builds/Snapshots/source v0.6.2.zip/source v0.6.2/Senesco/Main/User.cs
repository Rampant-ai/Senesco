﻿using System;
using log4net;
using Senesco.Objects;

namespace Senesco.Main
{
   public class User
   {
      private static readonly ILog s_log = LogManager.GetLogger(typeof(User));

      public string Username;
      public int UserId;
      public int IconId;
      public int Flags;

      public User()
      {
      }

      public User(UserListEntry ule)
      {
         string user = String.Format("({0}:{1}:{2})", ule.Nick.Value, ule.Icon.Value, ule.Socket.Value);
         s_log.Info(user);

         Username = ule.Nick.Value;
         UserId = ule.Socket.Value;
         IconId = ule.Icon.Value;
         Flags = ule.Status.Value; // 2 = admin, 1 = idle
      }

      public override string ToString()
      {
         return String.Format("{0} ({1}:{2}:{3})", Username, UserId, IconId, Flags);
      }
   }
}
