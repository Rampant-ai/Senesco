﻿using System.Collections.Generic;
using System.Windows;
using Senesco.Main;

namespace Senesco.Windows
{
   /// <summary>
   /// Interaction logic for UserListWindow.xaml
   /// </summary>
   public partial class UserListWindow : Window
   {
      private SenescoController m_controller;

      public UserListWindow(Window owner, SenescoController controller)
      {
         // Set up this new window.
         this.ShowInTaskbar = false;
         this.Owner = owner;
         PositionWindow(owner);
         InitializeComponent();

         // Configure the internals and user objects.
         m_controller = controller;
         RefreshUserList();
      }

      private void PositionWindow(Window parent)
      {
         if (parent == null)
            return;

         // TODO: try to get last saved positions

         // Position just off to the right at the same height.
         this.Left = parent.Left + parent.Width + 1;
         this.Top = parent.Top;
      }

      public Status ClearUserList()
      {
         // Clear the GUI list.
         usersListBox.Items.Clear();
         return Status.Success;
      }

      public Status RefreshUserList()
      {
         // Get the list of users from the model.
         List<User> userList;

         if (m_controller == null)
            return Status.Failure;
         
         userList = m_controller.UserList;

         if (userList == null || userList.Count == 0)
            return Status.Failure;

         // Clear the GUI list.
         usersListBox.Items.Clear();

         // Add a row for each user in the userList.
         foreach (User user in userList)
            usersListBox.Items.Add(user);

         return Status.Success;
      }

      private void sendPm_Click(object sender, RoutedEventArgs e)
      {
         Window pm = new PmSendWindow(this, m_controller, GetSelectedUser());
         pm.Show();
      }

      private void getUserInfo_Click(object sender, RoutedEventArgs e)
      {
         // Get currently selected user from usersListBox.
         User selectedUser = GetSelectedUser();

         // Send GetUserInfo transaction.
         m_controller.GetUserInfo(selectedUser);
      }

      private User GetSelectedUser()
      {
         if (usersListBox == null)
            return null;
         if (usersListBox.SelectedItem == null)
            return null;
         return usersListBox.SelectedItem as User;
      }
   }
}
