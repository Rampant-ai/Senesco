﻿using System;

namespace Senesco.Client.Main.Events
{
   public class ConnectedEventArgs : EventArgs
   {
      private readonly string m_message;

      public string Message
      {
         get { return m_message; }
      }

      public ConnectedEventArgs(string message)
      {
         m_message = message;
      }
   }
}
