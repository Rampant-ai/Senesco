﻿
namespace Senesco.Client.Main.Sound
{
   public enum SoundEffect
   {
      ChatClick,
      UserJoin,
      UserPart,
      PmReceived,
      PmSent,
      Connected,
      Disconnected
   }
}
