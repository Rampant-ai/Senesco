﻿using System;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using Senesco.Client.Main;
using Senesco.Client.Main.Sound;
using Senesco.Client.Utility;

namespace Senesco.WPF.Windows.Config
{
   /// <summary>
   /// Interaction logic for SoundsConfig.xaml
   /// </summary>
   public partial class SoundsConfig : Window, ISenescoWindow
   {
      public SoundsConfig(Window owner, SoundController soundController)
      {
         WindowUtils.ConfigureChildWindow(owner, this);
         InitializeComponent();
         WindowUtils.RestoreWindowPosition(this, owner, WindowUtils.DefaultPosition.CenterOnParent);

         if (soundController != null)
            DataContext = soundController;
      }

      private void SelectFile(object sender, RoutedEventArgs e)
      {
         Button button = sender as Button;
         if (button == null)
            return;

         SoundItem soundItem = button.DataContext as SoundItem;
         if (soundItem == null)
            return;

         string oldPath = soundItem.FilePath;

         // Open a dialog to have the user pick a file.
         // NOTE: I made a default filter for WAV files but for all I know the
         // SoundPlayer class will play others.  I added the "All files" filter
         // for this situation.
         OpenFileDialog ofd = new OpenFileDialog();
         ofd.Title = "Select .wav file";
         ofd.Multiselect = false;
         //ofd.InitialDirectory = "foo";
         ofd.Filter = "WAV files (*.wav)|*.wav|All files (*.*)|*.*";
         bool? result = ofd.ShowDialog(this);

         // If the user canceled or otherwise exited, do nothing.
         if (result == null || result == false)
            return;

         // Set the new path and submit it for loading.
         soundItem.FilePath = ofd.FileName;
         if (soundItem.Submit() != Status.Success)
         {
            soundItem.FilePath = oldPath;
            return;
         }

         // Save the new setting.
         soundItem.Save();
      }

      public void Window_SizeChanged(object sender, SizeChangedEventArgs e)
      {
         WindowUtils.SaveWindowPosition(this);
      }

      public void Window_LocationChanged(object sender, EventArgs e)
      {
         WindowUtils.SaveWindowPosition(this);
      }

      public void SaveWindowPosition()
      {
         ConfigSettings.UserSettings.SoundsConfigLeft = this.Left;
         ConfigSettings.UserSettings.SoundsConfigTop = this.Top;
      }

      public void RestoreWindowPosition()
      {
         this.Left = ConfigSettings.UserSettings.SoundsConfigLeft;
         this.Top = ConfigSettings.UserSettings.SoundsConfigTop;
      }

      private void SoundProfiles_SelectionChanged(object sender, SelectionChangedEventArgs e)
      {
         // Switch to the newly selected profile.
         ;
      }
   }
}
