﻿using System;
using System.Collections.Generic;
using System.Net;
using log4net;
using Senesco.Transactions;
using Senesco.Utility;
using System.Text;

namespace Senesco
{
   public class SenescoController
   {
      private static readonly ILog s_log = LogManager.GetLogger(typeof(SenescoController));
      private Server m_server = null;
      public Server ConfiguredServer = null;

      // Delegates for Transaction handling.
      public delegate void ChatReceivedDelegate(string text);
      public ChatReceivedDelegate ChatReceived = null;

      public delegate void DisconnectedDelegate();
      public DisconnectedDelegate Disconnected = null;

      public SenescoController()
      { }

      public Status Connect(Server settings)
      {
         return Connect(settings.ServerName, settings.Address, 
            settings.LoginName, settings.Password,
            settings.Nick, settings.Icon);
      }

      public Status Connect(string name, string address,
                            string username, string password,
                            string nick, int icon)
      {
         // Configure the Server object for connecting.
         m_server = new Server();
         m_server.ServerName = name;
         m_server.Address = address;

         // Set up the event delegates for this Server connection.
         m_server.ChatReceived = HandleChatReceived;
         m_server.Disconnected = HandleDisconnected;

         // Initiate server connection.
         if (m_server.Connect() == Status.Failure)
         {
            s_log.ErrorFormat("Connecting to {0} failed.", address);
            m_server = null;
            return Status.Failure;
         }

         // Send initial transactions.
         // "cmgguest", "cmgguest00"
         m_server.SendTransaction(new Login(username, password, nick, icon));
         m_server.SendTransaction(new GetUserList(null));

         // Send a notice to the chat window to make it clear you have been disconnected.
         LocalChat(String.Format("Connected to '{0}'", m_server.ServerName));

         return Status.Success;
      }

      public void Disconnect()
      {
         // Disconnect from any connected servers.
         if (m_server != null)
         {
            m_server.Disconnect();

            // Send a notice to the chat window to make it clear you have been disconnected.
            LocalChat(String.Format("Disconnected from '{0}'", m_server.ServerName));
         }
      }

      private void LocalChat(string message)
      {
         // Format the message with a timestamp after it.
         StringBuilder sb = new StringBuilder();
         sb.Append("\n<<< ");
         sb.Append(message);
         sb.Append(" >>>");
         sb.Append("\n<<< ");
         sb.Append(DateTime.Now.ToString());
         sb.Append(" >>>");

         // Submit the text to the chat system.
         HandleChatReceived(sb.ToString(), -1);
      }

      public void Shutdown()
      {
         Disconnect();
      }

      /// <summary>
      /// Sends the given chat string to the connected server.
      /// </summary>
      /// <param name="text">The chat string to process and send.</param>
      /// <returns>
      /// Status.Success if all chats were successfully queued.
      /// Status.NoResult if there was no chat to send, or no newlines were present.
      /// Status.Failure if there was chat to send but queueing failed.
      /// </returns>
      public Status CheckSendChat(string text)
      {
         if (text.Contains("\n") == false)
         {
            //s_log.Debug("No newline character - not sending chat");
            return Status.NoResult;
         }

         if (m_server == null)
         {
            s_log.ErrorFormat("Not sending chat - not connected to server");
            return Status.Failure;
         }

         s_log.Debug("Newline character found, and connected to a server - sending chat");

         List<string> chats = ProcessChat(text);

         if (chats == null || chats.Count == 0)
         {
            s_log.Debug("No chats to send.");
            return Status.NoResult;
         }

         // Send each chat in a separate SendChat transaction.
         Status result = Status.NoResult;
         foreach (string chat in chats)
         {
            result = m_server.SendTransaction(new SendChat(chat, null, 0));
            if (result == Status.Failure)
            {
               s_log.ErrorFormat("Sending chat failed: {0}", chat);
               return Status.Failure;
            }
         }
         return result;
      }

      private List<string> ProcessChat(string text)
      {
         //FIXME: moving the cursor to the middle of a block of text and pressing return to
         // send it will break up the chat into two pieces where the cursor was.

         // Split up the chat into an array of lines.
         // Each line will generally end with "\r\n" as CR and LF (windows line endings).
         char[] delimiters = new char[1] { '\n' };
         string[] rawLines = text.Split(delimiters);

         // Remove the newline characters from each line.
         List<string> finalLines = new List<string>();
         foreach (string rawLine in rawLines)
         {
            //string finalLine = rawLine.Replace("\r\n", "");
            string finalLine = rawLine.Trim();
            if (string.IsNullOrEmpty(finalLine) == false)
               finalLines.Add(finalLine);
         }
         return finalLines;
      }

      #region Incoming Transaction Delegates

      public void HandleChatReceived(string chatText, int chatWindow)
      {
         // If one is set, invoke the view's delegate.
         if (ChatReceived != null)
            ChatReceived(chatText);

         // Add this text to the chat log.
         //TODO:
      }

      public void HandleDisconnected()
      {
         // TODO: Invoke the view's delegate.
         // This is mainly so the view can update GUI controls.

         // Perform all of the back-end clean-up too.
         Disconnect();
      }

      #endregion
   }
}
