﻿using log4net;
using Senesco.Objects;

namespace Senesco.Transactions
{
   class UserChange : Transaction
   {
      private static readonly ILog s_log = LogManager.GetLogger(typeof(UserChange));

      private UserSocket m_userSocket;
      private Icon m_icon;
      private Nick m_nick;
      private UserStatus m_userStatus;

      /// <summary>
      /// Default creator for the Activator to use in the TransactionFactory.
      /// </summary>
      public UserChange()
         : base("UserChange")
      {
      }

      public UserChange(int userSocket, int icon, string nick, int userStatus)
         : base("UserChange", false, 0)
      {
         m_userSocket = new UserSocket(userSocket);
         m_icon = new Icon(icon);
         m_nick = new Nick(nick);
         m_userStatus = new UserStatus(userStatus);

         m_objectList.Add(m_userSocket);
         m_objectList.Add(m_icon);
         m_objectList.Add(m_nick);
         m_objectList.Add(m_userStatus);
      }

      protected override void ProcessObjectList()
      {
         foreach (HotlineObject obj in m_objectList)
         {
            if (obj.GetType() == typeof(UserSocket))
               m_userSocket = obj as UserSocket;
            else if (obj.GetType() == typeof(Icon))
               m_icon = obj as Icon;
            else if (obj.GetType() == typeof(Nick))
               m_nick = obj as Nick;
            else if (obj.GetType() == typeof(UserStatus))
               m_userStatus = obj as UserStatus;
            else
               s_log.ErrorFormat("Unexpected object: {0}", obj.GetType().ToString());
         }
      }
   }
}
