﻿using System;
using System.Collections.Generic;
using log4net;

namespace Senesco.Transactions
{
   class TransactionFactory
   {
      private static readonly ILog s_log = LogManager.GetLogger(typeof(TransactionFactory));

      #region Registration

      private static bool s_initialized = false;
      private static object s_initSync = new object();
      private static Dictionary<int, Type> s_idMap = new Dictionary<int, Type>();
      private static Dictionary<Type, int> s_typeMap = new Dictionary<Type, int>();

      private static void Initialize()
      {
         s_idMap[0] = typeof(Transaction);
         s_idMap[105] = typeof(SendChat);
         s_idMap[106] = typeof(RelayChat);
         s_idMap[107] = typeof(Login);
         s_idMap[111] = typeof(Disconnected);
         s_idMap[300] = typeof(GetUserList);
         s_idMap[301] = typeof(UserChange);
         s_idMap[302] = typeof(UserLeave);
         s_idMap[303] = typeof(GetUserInfo);

         // The other map is the exact opposite, which we can generate
         // with this simple loop.
         foreach (KeyValuePair<int, Type> kvp in s_idMap)
            s_typeMap[kvp.Value] = kvp.Key;

         s_initialized = true;
      }

      internal static int GetIdByType(Type type)
      {
         // Make sure multiple threads don't initialize simultaneously.
         lock (s_initSync)
         {
            if (s_initialized == false)
               Initialize();
         }

         return s_typeMap[type];
      }

      #endregion

      #region Factory

      internal static Transaction Create(bool reply, int transactionId, int taskNumber, int errorCode,
                                         byte[] transactionData, out Transaction replyTo)
      {
         replyTo = null;
         try
         {
            // Figure out what type is associated with the given ID number.
            // The default for unknown ID values is the base class.
            Type transType;
            if (s_idMap.TryGetValue(transactionId, out transType) == false)
            {
               s_log.InfoFormat("Unknown Transaction ID {0}", transactionId);
               transType = typeof(Transaction);
            }

            // Create an instance of that Type.
            Transaction transaction = (Transaction)Activator.CreateInstance(transType);

            // Configure the base instance with the fields we have.
            transaction.Configure(reply, transactionId, taskNumber, errorCode);

            // Have the transaction parse its own details.
            transaction.ParseObjects(transactionData);

            // Look up the transaction that this is a reply to.
            replyTo = Transaction.GetSourceTransaction(taskNumber);

            // Return the finished transaction.
            return transaction;
         }
         catch (Exception e)
         {
            s_log.ErrorFormat("Exception generating Transaction ID {0}: {1}", transactionId, e.Message);
            return null;
         }
      }

      #endregion
   }
}
