
Senesco
v. To grow old, to grow aged, to mature, wear out. 

-----------------------------------------------

Who says Hotline is old, aged, matured, or worn out?

...Oh, right.  Everybody.


Future Planned Features
-----------------------
-Add keyboard shortcuts for menu items.
-Hook up auto-reconnect system.
-Remove bookmarks via GUI.
-Register .sbm with Windows on startup (and/or install).

-Improve user list display (icons, operations, etc).
-Improve chat text display (hyperlinks, selections, etc).

-Add chat-prefix system for command entry (eg. /me says hi).
-Port to win32 console.
-Port to other platforms using Mono.
-Port to other GUI's using Mono by ditching WPF.


Known Issues
------------
-Connecting after your local IP has changed may consistently fail.  Needs more testing.
-Return key doesn't register when alt is held down (need to change input style drastically).
-Bookmarks are not encoded in any meaningful way, so your password is plaintext if you know where to look.


Features That Probably Won't Be Added
-------------------------------------
-News
-Files
-Agreement
-Trackers
