﻿
namespace Senesco.Main
{
   public class SoundController
   {
      private SoundItem m_chatClick = new SoundItem("ChatClick", "Chat Received");
      public SoundItem ChatClick
      {
         get { return m_chatClick; }
         set { m_chatClick = value; }
      }

      public SoundItem m_userJoin = new SoundItem("UserJoin", "User Joined");
      public SoundItem UserJoin
      {
         get { return m_userJoin; }
         set { m_userJoin = value; }
      }

      public SoundItem m_userPart = new SoundItem("UserPart", "User Parted");
      public SoundItem UserPart
      {
         get { return m_userPart; }
         set { m_userPart = value; }
      }

      public SoundItem m_receivePm = new SoundItem("ReceivePm", "PM Received");
      public SoundItem ReceivePm
      {
         get { return m_receivePm; }
         set { m_receivePm = value; }
      }

      public SoundItem m_sendPm = new SoundItem("SendPm", "PM Sent");
      public SoundItem SendPm
      {
         get { return m_sendPm; }
         set { m_sendPm = value; }
      }

      public SoundItem m_connected = new SoundItem("Connected", "Connected");
      public SoundItem Connected
      {
         get { return m_connected; }
         set { m_connected = value; }
      }

      public SoundItem m_disconnected = new SoundItem("Disconnected", "Disconnected");
      public SoundItem Disconnected
      {
         get { return m_disconnected; }
         set { m_disconnected = value; }
      }
   }
}
