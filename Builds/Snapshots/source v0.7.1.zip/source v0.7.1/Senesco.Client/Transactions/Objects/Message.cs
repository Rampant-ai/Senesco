﻿
using Senesco.Transactions.Objects.ObjectData;
using Senesco.Utility;

namespace Senesco.Transactions.Objects
{
   class Message : HotlineObject
   {
      public NormalString Value;

      /// <summary>
      /// Default creator for the ObjectFactory to use.
      /// </summary>
      public Message()
      { }

      public Message(string message)
      {
         Value = new NormalString(message);
         this.ObjectDataList.Add(Value);
      }

      internal override void ParseBytes(byte[] objectData)
      {
         int index = 0;
         string message = DataUtils.ReadString(objectData, ref index, objectData.Length);

         Value = new NormalString(message);
         this.ObjectDataList.Add(Value);
      }
   }
}
