﻿
using Senesco.Transactions.Objects.ObjectData;
using Senesco.Utility;

namespace Senesco.Transactions.Objects
{
   class Parameter : HotlineObject
   {
      public Number Value;

      /// <summary>
      /// Default creator for the ObjectFactory to use.
      /// </summary>
      public Parameter()
      { }

      public Parameter(int parameter)
      {
         Value = new Number(parameter);
         this.ObjectDataList.Add(Value);
      }

      internal override void ParseBytes(byte[] objectData)
      {
         int index = 0;
         int parameter = DataUtils.ReadNumber(objectData, ref index);

         Value = new Number(parameter);
         this.ObjectDataList.Add(Value);
      }
   }
}
