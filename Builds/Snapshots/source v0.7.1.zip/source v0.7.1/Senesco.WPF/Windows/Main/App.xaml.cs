﻿using System.Windows;
using Senesco.Utility;

namespace Senesco.Windows.Main
{
   /// <summary>
   /// Interaction logic for App.xaml
   /// </summary>
   public partial class App : Application
   {
      public App()
         : base()
      {
      }

      /// <summary>
      /// This event handler stores the command line (startup event) arguments
      /// in App.Properties for use later when the program is ready to handle
      /// processing them.
      /// </summary>
      /// <param name="sender"></param>
      /// <param name="e"></param>
      private void Application_Startup(object sender, StartupEventArgs e)
      {
         this.Properties["StartupArgs"] = e.Args;
      }
   }
}
