﻿using System;
using System.Windows;
using Senesco.Main;
using Senesco.Utility;

namespace Senesco.Windows.Config
{
   /// <summary>
   /// Interaction logic for UserConfig.xaml
   /// </summary>
   public partial class UserConfig : Window, ISenescoWindow
   {
      public UserConfig(Window owner, SenescoController controller)
      {
         WindowUtils.ConfigureChildWindow(owner, this);
         InitializeComponent();
         WindowUtils.RestoreWindowPosition(this, owner, WindowUtils.DefaultPosition.CenterOnParent);

         DataContext = controller;

         // Initialize the fields with the current values.
         m_icon.Text = controller.CurrentIcon.ToString();
         m_nick.Text = controller.CurrentNick;
      }

      #region Window Management

      public void Window_SizeChanged(object sender, SizeChangedEventArgs e)
      {
         WindowUtils.SaveWindowPosition(this);
      }

      public void Window_LocationChanged(object sender, EventArgs e)
      {
         WindowUtils.SaveWindowPosition(this);
      }

      public void SaveWindowPosition()
      {
         ConfigSettings.UserSettings.UserConfigLeft = this.Left;
         ConfigSettings.UserSettings.UserConfigTop = this.Top;
      }

      public void RestoreWindowPosition()
      {
         this.Left = ConfigSettings.UserSettings.UserConfigLeft;
         this.Top = ConfigSettings.UserSettings.UserConfigTop;
      }

      #endregion
   }
}
