﻿using System.Collections.Generic;
using System.Windows;
using Senesco.Main;
using Senesco.Utility;
using Senesco.Windows.Dialog;

namespace Senesco.Windows.Main
{
   /// <summary>
   /// Interaction logic for UserListWindow.xaml
   /// </summary>
   public partial class UserListWindow : Window
   {
      private SenescoController m_controller;

      public UserListWindow(Window owner, SenescoController controller)
      {
         // Set up this new window.
         WindowUtils.ConfigureChildWindow(owner, this);
         InitializeComponent();
         PositionWindow(owner);

         // Configure the internals and user objects.
         m_controller = controller;
         RefreshUserList();
      }

      private void PositionWindow(Window parent)
      {
         // Try to restore last saved position.
         if (WindowUtils.RestoreWindowPosition(this) == Status.Success)
            return;

         // Otherwise align this window just right of the main window.
         WindowUtils.ChildRightSideOfParent(parent, this);
      }

      public Status ClearUserList()
      {
         // Clear the GUI list.
         usersListBox.Items.Clear();
         return Status.Success;
      }

      public Status RefreshUserList()
      {
         // Get the list of users from the model.
         List<User> userList;

         if (m_controller == null)
            return Status.Failure;
         
         userList = m_controller.UserList;

         if (userList == null || userList.Count == 0)
            return Status.Failure;

         // Clear the GUI list.
         usersListBox.Items.Clear();

         // Add a row for each user in the userList.
         foreach (User user in userList)
            usersListBox.Items.Add(user);

         return Status.Success;
      }

      private void sendPm_Click(object sender, RoutedEventArgs e)
      {
         Window pm = new PmSendWindow(this, m_controller, GetSelectedUser());
         pm.Show();
      }

      private void getUserInfo_Click(object sender, RoutedEventArgs e)
      {
         // Get currently selected user from usersListBox.
         User selectedUser = GetSelectedUser();

         // Send GetUserInfo transaction.
         m_controller.GetUserInfo(selectedUser);
      }

      private User GetSelectedUser()
      {
         if (usersListBox == null)
            return null;
         if (usersListBox.SelectedItem == null)
            return null;
         return usersListBox.SelectedItem as User;
      }

      private void Window_SizeChanged(object sender, SizeChangedEventArgs e)
      {
         WindowUtils.SaveWindowPosition(this);
      }

      private void Window_LocationChanged(object sender, System.EventArgs e)
      {
         WindowUtils.SaveWindowPosition(this);
      }
   }
}
