﻿using System;
using System.Windows;
using Senesco.Main;
using Senesco.Utility;

namespace Senesco.Windows.Dialog
{
   /// <summary>
   /// Interaction logic for PmSendWindow.xaml
   /// </summary>
   public partial class PmSendWindow : Window
   {
      private SenescoController m_controller;
      private User m_targetUser;

      public PmSendWindow(Window owner, SenescoController controller, User targetUser)
      {
         WindowUtils.ConfigureChildWindow(owner, this);
         InitializeComponent();
         WindowUtils.CenterChildOnParent(owner, this);

         m_controller = controller;
         m_targetUser = targetUser;
         
         if (m_targetUser != null)
            this.recipientLabel.Content = String.Format("Recipient: {0}", m_targetUser.Username);
      }

      private void PositionWindow(Window parent)
      {
         if (parent == null)
            return;

         // Position centered over the userlist.
         this.Left = parent.Left + (parent.Width / 2) - (this.Width / 2);
         this.Top = parent.Top + (parent.Height / 2) - (this.Height / 2);
      }

      private void sendButton_Click(object sender, RoutedEventArgs e)
      {
         // Send the private message text from this window.
         if (m_controller != null && this.pmText.Text.Length > 0)
            m_controller.SendPrivateMessage(m_targetUser, this.pmText.Text);

         // Close this window.
         this.Close();
      }

      private void cancelButton_Click(object sender, RoutedEventArgs e)
      {
         // Close the window without doing anything.
         this.Close();
      }
   }
}
