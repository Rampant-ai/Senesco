﻿using System;
using System.Windows;
using log4net;
using Senesco.Windows.Config;
using Senesco.Windows.Main;

namespace Senesco.Utility
{
   class WindowUtils
   {
      private static readonly ILog s_log = LogManager.GetLogger(typeof(WindowUtils));

      /// <summary>
      /// For consistent configuration of parent/child windows.
      /// </summary>
      public static void ConfigureChildWindow(Window parent, Window child)
      {
         child.ShowInTaskbar = false;
         child.Owner = parent;
      }

      /// <summary>
      /// Window alignment helper.
      /// </summary>
      public static void CenterChildOnParent(Window parent, Window child)
      {
         if (parent == null || child == null)
            return;

         // Position centered over the userlist.
         child.Left = parent.Left + (parent.Width / 2) - (child.Width / 2);
         child.Top = parent.Top + (parent.Height / 2) - (child.Height / 2);
      }

      /// <summary>
      /// Window alignment helper.
      /// </summary>
      public static void ChildRightSideOfParent(Window parent, Window child)
      {
         if (parent == null || child == null)
            return;

         // Position just off to the right at the same height.
         child.Left = parent.Left + parent.Width + 1;
         child.Top = parent.Top;
      }

      /// <summary>
      /// Restores the last saved window position for this window.
      /// </summary>
      public static Status RestoreWindowPosition(Window window)
      {
         if (window == null)
            return Status.NoResult;

         Type type = window.GetType();

         try
         {
            if (type == typeof(ChatWindow))
            {
               window.Left = ConfigSettings.UserSettings.ChatWindowLeft;
               window.Top = ConfigSettings.UserSettings.ChatWindowTop;
               window.Width = ConfigSettings.UserSettings.ChatWindowWidth;
               window.Height = ConfigSettings.UserSettings.ChatWindowHeight;
               return Status.Success;
            }
            else if (type == typeof(UserListWindow))
            {
               window.Left = ConfigSettings.UserSettings.UserListWindowLeft;
               window.Top = ConfigSettings.UserSettings.UserListWindowTop;
               window.Width = ConfigSettings.UserSettings.UserListWindowWidth;
               window.Height = ConfigSettings.UserSettings.UserListWindowHeight;
               return Status.Success;
            }
            else if (type == typeof(SoundsConfig))
            {
               window.Left = ConfigSettings.UserSettings.SoundsConfigLeft;
               window.Top = ConfigSettings.UserSettings.SoundsConfigTop;
               return Status.Success;
            }
            return Status.Failure;
         }
         catch (Exception e)
         {
            s_log.ErrorFormat("Error restoring window position: {0}", e.Message);
            return Status.Failure;
         }
      }

      public static Status SaveWindowPosition(Window window)
      {
         if (window == null)
            return Status.NoResult;

         Type type = window.GetType();

         try
         {
            if (type == typeof(ChatWindow))
            {
               ConfigSettings.UserSettings.ChatWindowLeft = window.Left;
               ConfigSettings.UserSettings.ChatWindowTop = window.Top;
               ConfigSettings.UserSettings.ChatWindowWidth = window.Width;
               ConfigSettings.UserSettings.ChatWindowHeight = window.Height;
               ConfigSettings.UserSettings.Save();
               return Status.Success;
            }
            else if (type == typeof(UserListWindow))
            {
               ConfigSettings.UserSettings.UserListWindowLeft = window.Left;
               ConfigSettings.UserSettings.UserListWindowTop = window.Top;
               ConfigSettings.UserSettings.UserListWindowWidth = window.Width;
               ConfigSettings.UserSettings.UserListWindowHeight = window.Height;
               ConfigSettings.UserSettings.Save();
               return Status.Success;
            }
            else if (type == typeof(SoundsConfig))
            {
               ConfigSettings.UserSettings.SoundsConfigLeft = window.Left;
               ConfigSettings.UserSettings.SoundsConfigTop = window.Top;
               ConfigSettings.UserSettings.Save();
               return Status.Success;
            }
            return Status.Failure;
         }
         catch (Exception e)
         {
            s_log.ErrorFormat("Error restoring window position: {0}", e.Message);
            return Status.Failure;
         }
      }
   }
}
