﻿using System;
using System.Text;
using System.Windows;
using System.Windows.Documents;
using Senesco.Main;
using Senesco.Utility;

namespace Senesco.Windows.Dialog
{
   /// <summary>
   /// Interaction logic for PmSendWindow.xaml
   /// </summary>
   public partial class PmSendWindow : Window
   {
      private SenescoController m_controller;
      private User m_targetUser;

      public PmSendWindow(Window owner, SenescoController controller, User targetUser)
      {
         WindowUtils.ConfigureChildWindow(owner, this);
         InitializeComponent();
         WindowUtils.CenterChildOnParent(owner, this);

         m_controller = controller;
         m_targetUser = targetUser;
         
         if (m_targetUser != null)
            m_recipientLabel.Content = String.Format("Recipient: {0}", m_targetUser.Username);
      }

      private void PositionWindow(Window parent)
      {
         if (parent == null)
            return;

         // Position centered over the userlist.
         this.Left = parent.Left + (parent.Width / 2) - (this.Width / 2);
         this.Top = parent.Top + (parent.Height / 2) - (this.Height / 2);
      }

      private void CancelButton_Click(object sender, RoutedEventArgs e)
      {
         // Close the window without doing anything.
         this.Close();
      }

      private void SendButton_Click(object sender, RoutedEventArgs e)
      {
         // Send the private message text entered in this window.
         SendPm_RichTextBox();

         // Close this window.
         this.Close();
      }

      /*
      private void SendPm_TextBox()
      {
         string message = m_pmText.Text;
         if (m_controller != null && message.Length > 0)
            m_controller.SendPrivateMessage(m_targetUser, message);
      }
      */

      private void SendPm_RichTextBox()
      {
         if (m_pmText.Document == null || m_pmText.Document.Blocks == null)
            return;

         StringBuilder sb = new StringBuilder();
         foreach (Block block in m_pmText.Document.Blocks)
         {
            Paragraph paragraph = block as Paragraph;
            if (paragraph == null)
               continue;

            foreach (Inline inline in paragraph.Inlines)
            {
               Run run = inline as Run;
               if (run == null)
                  continue;

               sb.AppendLine(run.Text);
            }
         }

         string message = sb.ToString();

         if (m_controller != null && message.Length > 0)
            m_controller.SendPrivateMessage(m_targetUser, message);
      }
   }
}
