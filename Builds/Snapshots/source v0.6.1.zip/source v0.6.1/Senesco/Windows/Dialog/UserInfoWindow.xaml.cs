﻿using System.Windows;
using Senesco.Utility;

namespace Senesco.Windows.Dialog
{
   /// <summary>
   /// Interaction logic for UserInfoWindow.xaml
   /// </summary>
   public partial class UserInfoWindow : Window
   {
      public UserInfoWindow(Window owner, string userInfoText)
      {
         WindowUtils.ConfigureChildWindow(owner, this);
         InitializeComponent();
         WindowUtils.CenterChildOnParent(owner, this);

         m_userInfoText.AppendText(userInfoText);
      }

      private void DismissButton_Click(object sender, RoutedEventArgs e)
      {
         this.Close();
      }
   }
}
