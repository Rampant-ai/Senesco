﻿using System;
using System.ComponentModel;
using Senesco.Utility;
using System.Collections.Generic;

namespace Senesco.Main
{
   public class SoundItem : INotifyPropertyChanged
   {
      #region Fields and Properties
      
      // Internal name used to configure and play the sound.
      private String m_name;
      public String Name
      {
         get { return m_name; }
         set
         {
            m_name = value;
            NotifyPropertyChanged("Name");
         }
      }

      // User interface label string.
      private String m_label;
      public String Label
      {
         get { return m_label; }
         set
         {
            m_label = value;
            NotifyPropertyChanged("Label");
         }
      }
      
      // Actual path to the sound file.
      private String m_filePath;
      public String FilePath
      {
         get { return m_filePath; }
         set
         {
            m_filePath = value;
            NotifyPropertyChanged("FilePath");
         }
      }

      #endregion

      #region Creator

      public SoundItem(string name, string label)
      {
         Name = name;
         Label = label;

         // Restore the previously saved path.
         FilePath = ConfigSettings.UserSettings.GetSoundPath(Name);
         // Load the sound file.
         Submit();
      }

      #endregion

      /// <summary>
      /// Submits the current SoundItem for loading.
      /// </summary>
      /// <returns>True if error, otherwise false.</returns>
      public Status Submit()
      {
         if (String.IsNullOrEmpty(Name) || String.IsNullOrEmpty(FilePath))
            return Status.Failure;
         return SoundUtils.SetSound(Name, FilePath);
      }

      /// <summary>
      /// Save the current configuration of this SoundItem.
      /// </summary>
      public void Save()
      {
         ConfigSettings.UserSettings.SaveSoundPath(Name, FilePath);
         ConfigSettings.UserSettings.Save();
      }

      /// <summary>
      /// Plays this sound if possible.
      /// </summary>
      public void Play()
      {
         SoundUtils.PlaySound(Name);
      }

      #region INotifyPropertyChanged

      public event PropertyChangedEventHandler PropertyChanged;

      private void NotifyPropertyChanged(String info)
      {
         if (PropertyChanged != null)
            PropertyChanged(this, new PropertyChangedEventArgs(info));
      }

      #endregion
   }
}
