﻿using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using Senesco.Main;
using Senesco.Utility;
using System;

namespace Senesco.Windows.Config
{
   /// <summary>
   /// Interaction logic for SoundsConfig.xaml
   /// </summary>
   public partial class SoundsConfig : Window
   {
      public SoundsConfig(Window owner, SenescoController controller)
      {
         WindowUtils.ConfigureChildWindow(owner, this);
         InitializeComponent();
         if (WindowUtils.RestoreWindowPosition(this) == Status.Failure)
            WindowUtils.CenterChildOnParent(owner, this);

         if (controller != null)
            DataContext = controller.Sounds;
      }

      private void SelectFile(object sender, RoutedEventArgs e)
      {
         Button button = sender as Button;
         if (button == null)
            return;

         SoundItem soundItem = button.DataContext as SoundItem;
         if (soundItem == null)
            return;

         string oldPath = soundItem.FilePath;

         // Open a dialog to have the user pick a file.
         // NOTE: I made a default filter for WAV files but for all I know the
         // SoundPlayer class will play others.  I added the "All files" filter
         // for this situation.
         OpenFileDialog ofd = new OpenFileDialog();
         ofd.Title = "Select .wav file";
         ofd.Multiselect = false;
         //ofd.InitialDirectory = "foo";
         ofd.Filter = "WAV files (*.wav)|*.wav|All files (*.*)|*.*";
         bool? result = ofd.ShowDialog(this);

         // If the user canceled or otherwise exited, do nothing.
         if (result == null || result == false)
            return;

         // Set the new path and submit it for loading.
         soundItem.FilePath = ofd.FileName;
         if (soundItem.Submit() != Status.Success)
         {
            soundItem.FilePath = oldPath;
            return;
         }

         // Save the new setting.
         soundItem.Save();
      }

      private void Window_SizeChanged(object sender, SizeChangedEventArgs e)
      {
         WindowUtils.SaveWindowPosition(this);
      }

      private void Window_LocationChanged(object sender, System.EventArgs e)
      {
         WindowUtils.SaveWindowPosition(this);
      }
   }
}
