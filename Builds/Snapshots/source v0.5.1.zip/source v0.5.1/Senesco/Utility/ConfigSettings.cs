﻿using System.Collections.Generic;
using System.Configuration;
using log4net;
using System;

namespace Senesco.Utility
{
   class ConfigSettings : ApplicationSettingsBase
   {
      private static readonly ILog s_log = LogManager.GetLogger(typeof(ConfigSettings));

      public static ConfigSettings UserSettings = new ConfigSettings();

      #region Chat Window Coordinates

      [UserScopedSetting()]
      [DefaultSettingValue("20")]
      public double ChatWindowLeft
      {
         get { return (double)this["ChatWindowLeft"]; }
         set { this["ChatWindowLeft"] = value; }
      }
      [UserScopedSetting()]
      [DefaultSettingValue("20")]
      public double ChatWindowTop
      {
         get { return (double)this["ChatWindowTop"]; }
         set { this["ChatWindowTop"] = value; }
      }
      [UserScopedSetting()]
      [DefaultSettingValue("550")]
      public double ChatWindowWidth
      {
         get { return (double)this["ChatWindowWidth"]; }
         set { this["ChatWindowWidth"] = value; }
      }
      [UserScopedSetting()]
      [DefaultSettingValue("350")]
      public double ChatWindowHeight
      {
         get { return (double)this["ChatWindowHeight"]; }
         set { this["ChatWindowHeight"] = value; }
      }

      #endregion

      #region User List Window Coordinates

      [UserScopedSetting()]
      [DefaultSettingValue("572")]
      public double UserListWindowLeft
      {
         get { return (double)this["UserListWindowLeft"]; }
         set { this["UserListWindowLeft"] = value; }
      }
      [UserScopedSetting()]
      [DefaultSettingValue("20")]
      public double UserListWindowTop
      {
         get { return (double)this["UserListWindowTop"]; }
         set { this["UserListWindowTop"] = value; }
      }
      [UserScopedSetting()]
      [DefaultSettingValue("280")]
      public double UserListWindowWidth
      {
         get { return (double)this["UserListWindowWidth"]; }
         set { this["UserListWindowWidth"] = value; }
      }
      [UserScopedSetting()]
      [DefaultSettingValue("350")]
      public double UserListWindowHeight
      {
         get { return (double)this["UserListWindowHeight"]; }
         set { this["UserListWindowHeight"] = value; }
      }

      #endregion

      #region Sounds Config Window Coordinates

      [UserScopedSetting()]
      [DefaultSettingValue("20")]
      public double SoundsConfigLeft
      {
         get { return (double)this["SoundsConfigLeft"]; }
         set { this["SoundsConfigLeft"] = value; }
      }
      [UserScopedSetting()]
      [DefaultSettingValue("20")]
      public double SoundsConfigTop
      {
         get { return (double)this["SoundsConfigTop"]; }
         set { this["SoundsConfigTop"] = value; }
      }

      #endregion

      #region Sound Settings

      // There needs to be a property for each sound path to save, and it should
      // be named after the SoundItem Name property so the reflection works.
      [UserScopedSetting()]
      public string ChatClick { get; set; }
      [UserScopedSetting()]
      public string UserJoin { get; set; }
      [UserScopedSetting()]
      public string UserPart { get; set; }
      [UserScopedSetting()]
      public string ReceivePm { get; set; }
      [UserScopedSetting()]
      public string SendPm { get; set; }
      [UserScopedSetting()]
      public string Connected { get; set; }
      [UserScopedSetting()]
      public string Disconnected { get; set; }

      public Status SaveSoundPath(string name, string path)
      {
         if (String.IsNullOrEmpty(name))
            return Status.Failure;

         this[name] = path;
         Save();
         
         return Status.Success;
      }

      public string GetSoundPath(string name)
      {
         try
         {
            return (string)this[name];
         }
         catch (Exception e)
         {
            s_log.ErrorFormat("Exception restoring sound path: {0}", e.Message);
            return null;
         }
      }

      #endregion
   }
}
