﻿using System;
using System.Windows;
using System.Windows.Controls;
using log4net;
using Senesco.Utility;

namespace Senesco.Windows
{
   /// <summary>
   /// Interaction logic for ChatWindow.xaml
   /// </summary>
   public partial class ChatWindow : Window
   {
      private static readonly ILog s_log = LogManager.GetLogger(typeof(ChatWindow));

      private SenescoController m_controller = null;

      // GUI delegate definitions.
      public delegate void NoParamDelegate();
      public delegate void ChatDelegate(string text);

      public ChatWindow()
      {
         Log.InitLogging();

         InitializeComponent();
         
         m_controller = new SenescoController();
         m_controller.ChatReceived = chatReceived;
         m_controller.Disconnected = disconnected;
         SetWindowTitle(null);
      }

      private void Window_Closed(object sender, EventArgs e)
      {
         m_controller.Shutdown();
         Application.Current.Shutdown();
      }

      void SetWindowTitle(string serverName)
      {
         // If empty name given, just "Senesco".
         if (string.IsNullOrEmpty(serverName))
            this.Title = "Senesco";
         // Otherwise, suffix the server name.
         else
            this.Title = string.Format("Senesco: {0}", serverName);
      }

      #region Chat

      private void chatEntry_TextChanged(object sender, TextChangedEventArgs e)
      {
         //TODO: is the alt key held down?

         //TODO: Disable the chat box until connected to a server.

         // Try to send the text.  If that was successful, clear the text box.
         if (m_controller.CheckSendChat(this.chatEntry.Text) == Status.Success)
            this.chatEntry.Text = string.Empty;
      }

      private void chatReceived(string text)
      {
         Dispatcher.Invoke(new ChatDelegate(updateChatBox), text);
      }

      private void updateChatBox(string text)
      {
         this.chatBox.Text += text;
      }

      #endregion

      #region Connection Controls

      private void connectDialog_Click(object sender, RoutedEventArgs e)
      {
         // Display new connection window.
         ConnectWindow connectWindow = new ConnectWindow(m_controller);
         connectWindow.ShowDialog();

         // If the window did not configure a server, do nothing.
         if (connectWindow.ConfiguredServer == null)
         {
            s_log.InfoFormat("Connection window did not configure a server.");
            return;
         }

         // Connect using the settings from the other window.
         Status connect = m_controller.Connect(connectWindow.ConfiguredServer);

         // If connected successfully, update the window title with the server name.
         if (connect == Status.Success)
            SetWindowTitle(connectWindow.ConfiguredServer.ServerName);
      }

      private void disconnectMenu_Click(object sender, RoutedEventArgs e)
      {
         m_controller.Disconnect();
         SetWindowTitle(null);
         disconnectedEvent();
      }

      private void disconnected()
      {
         Dispatcher.Invoke(new NoParamDelegate(disconnectedEvent));
      }

      private void disconnectedEvent()
      {
         //TODO: Disable the "Disconnect" menu option since no longer connected.
         // other gui changes when becoming disconnected?
      }

      #endregion

      #region User Options

      private void userSettingsMenu_Click(object sender, RoutedEventArgs e)
      {
         // Bring up user settings dialog.
      }
      
      #endregion
   }
}
