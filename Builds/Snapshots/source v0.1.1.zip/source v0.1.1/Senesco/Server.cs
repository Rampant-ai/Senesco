﻿using System;
using System.Net;
using System.Net.Sockets;
using log4net;
using Senesco.Communication;
using Senesco.Objects;
using Senesco.Transactions;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Senesco
{
   [Serializable()]
   public class Server : ISerializable
   {
      #region Members and Creators

      private static readonly ILog s_log = LogManager.GetLogger(typeof(Server));

      public string ServerName;
      public string Address;
      public string LoginName;
      public string Password;
      public string Nick;
      public int Icon;

      private Connection m_channel = null;

      // Delegate types for incoming Transactions.
      public delegate void ChatReceivedDelegate(string chatText, int chatWindow);
      public delegate void DisconnectedDelegate();

      // Delegate settings for this class.
      public ChatReceivedDelegate ChatReceived = null;
      public DisconnectedDelegate Disconnected = null;

      public Server()
      {
      }

      public Server(SerializationInfo info, StreamingContext ctxt)
      {
         this.ServerName = info.GetString("ServerName");
         this.Address = info.GetString("Address");
         this.LoginName = info.GetString("LoginName");
         this.Password = info.GetString("Password");
         this.Nick = info.GetString("Nick");
         this.Icon = info.GetInt32("Icon");
      }
         
      public void GetObjectData(SerializationInfo info, StreamingContext ctxt)
      {
         info.AddValue("ServerName", this.ServerName);
         info.AddValue("Address", this.Address.ToString());
         info.AddValue("LoginName", this.LoginName);
         info.AddValue("Password", this.Password);
         info.AddValue("Nick", this.Nick);
         info.AddValue("Icon", this.Icon);
      }

      #endregion

      #region Connect and Disconnect

      public Status Connect()
      {
         Disconnect();

         // Only create a new Connection if we've never made one before.
         // Otherwise we re-use the same socket.
         if (m_channel == null)
            m_channel = new Connection();

         // Establish TCP connection.
         m_channel.Connect(this);

         // Send Hotline handshake.
         Package clientHello = new Package(new RawString("TRTPHOTL"), 0, 1, 0, 2);
         m_channel.Send(clientHello);

         // Start the socket data reader thread so incoming data will fill our byte queue.
         m_channel.BeginSocketReceive();

         // Read the handshake response from the server.
         Package serverHello;
         m_channel.ReceiveHandshake(out serverHello);

         // Confirm the correct handshake response.
         if (serverHello != new Package(new RawString("TRTP"), 0, 0, 0, 0))
         {
            s_log.ErrorFormat("Incorrect handshake received.");
            return Status.Failure;
         }

         s_log.InfoFormat("Correct handshake received!");

         // Specify the delegate to call when a transaction is received.
         m_channel.TransactionReceived = ReceiveTransaction;

         // Start the socket listening for transactions.
         m_channel.ListenForTransactions();

         return Status.Success;
      }

      public void Disconnect()
      {
         if (m_channel != null)
            m_channel.Disconnect();
      }

      #endregion

      #region Send and Receive Transaction

      public Status SendTransaction(Transaction t)
      {
         if (m_channel == null)
         {
            s_log.ErrorFormat("Not connected to server.");
            return Status.Failure;
         }
         if (t == null)
         {
            s_log.ErrorFormat("Null transaction provided.  Not sending.");
            return Status.Failure;
         }

         // Returns Success if the transaction was successfully queued.
         return m_channel.SendTransaction(t);
      }

      public Status ReceiveTransaction(Transaction inTransaction, Transaction replyTo)
      {
         if (inTransaction == null)
            return Status.Failure;

         s_log.InfoFormat("Received Transaction ID {0} '{1}': ({2})",
                          inTransaction.Id.Value, inTransaction.Name, inTransaction.GetType().ToString());

         Type inType = inTransaction.GetType();
         Type replyType = (replyTo == null) ? null : replyTo.GetType();

         if (inType == typeof(RelayChat))
            HandleRelayChat(inTransaction as RelayChat);
         else if (inType == typeof(Disconnected))
            HandleDisconnected(inTransaction as Disconnected);
         else if (replyType == typeof(Login))
            HandleLoginResponse(inTransaction);
         else if (replyType == typeof(GetUserList))
            HandleGetUserList(inTransaction);
         else if (inType == typeof(Transaction))
            s_log.WarnFormat("Unsupported Transaction received: {0}", inTransaction.Id.Value);
         else
            s_log.WarnFormat("Unsupported Transaction {0} '{1}' received: ({2})",
                             inTransaction.Id.Value, inTransaction.Name, inTransaction.GetType().ToString());

         return Status.Success;
      }

      #endregion

      #region Transaction Handler Methods

      private void HandleLoginResponse(Transaction loginResponse)
      {
         s_log.InfoFormat("Received login response.");
         // do something?
      }

      private void HandleDisconnected(Disconnected disconnected)
      {
         s_log.InfoFormat("Received Disconnected event.");
         // do something?
      }

      private void HandleGetUserList(Transaction userList)
      {
         s_log.InfoFormat("Received userlist response.");
         // do something?
      }

      private void HandleRelayChat(RelayChat relayChat)
      {
         if (relayChat == null)
            return;

         // The ChatWindow object is only specified for private chats.
         int chatWindow = -1;
         if (relayChat.ChatWindow != null)
         {
            chatWindow = relayChat.ChatWindow.Value.Value;
            s_log.DebugFormat("Chat is for window {0}.", chatWindow);
         }

         s_log.DebugFormat("Chat text: {0}", relayChat.Message.Value.Value);

         // Submit this transaction's "message" object to the chat delegate.
         if (ChatReceived != null)
            ChatReceived(relayChat.Message.Value.Value, chatWindow);
      }

      #endregion
   }
}
