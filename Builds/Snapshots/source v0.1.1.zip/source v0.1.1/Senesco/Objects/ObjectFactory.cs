﻿using System;
using System.Collections.Generic;
using log4net;

namespace Senesco.Objects
{
   class ObjectFactory
   {
      private static readonly ILog s_log = LogManager.GetLogger(typeof(ObjectFactory));

      #region Registration

      private static bool s_initialized = false;
      private static object s_initSync = new object();
      private static Dictionary<int, Type> s_idMap = new Dictionary<int, Type>();
      private static Dictionary<Type, int> s_typeMap = new Dictionary<Type, int>();

      private static void Initialize()
      {
         s_idMap[0] = typeof(HotlineObject);
         s_idMap[100] = typeof(ErrorMessage);
         s_idMap[101] = typeof(Message);
         s_idMap[102] = typeof(Nick);
         s_idMap[104] = typeof(Icon);
         s_idMap[105] = typeof(Username);
         s_idMap[106] = typeof(Password);
         s_idMap[109] = typeof(Parameter);
         s_idMap[114] = typeof(ChatWindow);
         s_idMap[160] = typeof(HotlineObject); // Unknown
         s_idMap[161] = typeof(HotlineObject); // Unknown
         s_idMap[162] = typeof(HotlineObject); // Server name
         s_idMap[300] = typeof(UserListEntry);

         // The other map is the exact opposite, which we can generate
         // with this simple loop.
         foreach (KeyValuePair<int, Type> kvp in s_idMap)
            s_typeMap[kvp.Value] = kvp.Key;

         s_initialized = true;
      }

      internal static int GetIdByType(Type type)
      {
         // Make sure multiple threads don't initialize simultaneously.
         lock (s_initSync)
         {
            if (s_initialized == false)
               Initialize();
         }

         return s_typeMap[type];
      }

      #endregion


      internal static HotlineObject Create(int objectId, byte[] objectData)
      {
         try
         {
            // Figure out what type is associated with the given ID number.
            Type objType;
            if (s_idMap.TryGetValue(objectId, out objType) == false)
            {
               s_log.InfoFormat("Unknown Object ID {0}", objectId);
               objType = typeof(HotlineObject);
            }

            // Create an instance of that Type.
            HotlineObject hotlineObject = (HotlineObject)Activator.CreateInstance(objType);

            // Have the object parse its own details from the byte array.
            hotlineObject.ParseBytes(objectData);

            // Return the finished object.
            return hotlineObject;
         }
         catch (Exception e)
         {
            s_log.ErrorFormat("Exception generating object ID {0}: {1}", objectId, e.Message);
            return null;
         }
      }
   }
}
