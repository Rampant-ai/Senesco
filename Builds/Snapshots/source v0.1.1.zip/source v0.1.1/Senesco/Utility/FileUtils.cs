﻿using System;
using System.IO;
using System.Xml.Serialization;
using log4net;
using System.Runtime.Serialization.Formatters.Binary;

namespace Senesco.Utility
{
   class FileUtils
   {
      private static readonly ILog s_log = LogManager.GetLogger(typeof(FileUtils));

      private static string s_bookmarkDirectory = string.Empty;

      public static Status SaveBookmark(Server server)
      {
         try
         {
            string filename = server.ServerName + ".sbm";
            string fullPath = Path.Combine(GetBookmarkDirectory(), filename);
            using (FileStream fs = new FileStream(fullPath, FileMode.Create))
            {
               BinaryFormatter serializer = new BinaryFormatter();
               serializer.Serialize(fs, server);
            }
            return Status.Success;
         }
         catch (Exception e)
         {
            s_log.ErrorFormat("Error saving bookmark: {0}", e.Message);
            return Status.Failure;
         }
      }

      private static string GetBookmarkDirectory()
      {
         string dir = Path.Combine("%APPDATA%", Path.Combine("Senesco", "Bookmarks"));
         dir  = Environment.ExpandEnvironmentVariables(dir);
         if (Directory.Exists(dir) == false)
            Directory.CreateDirectory(dir);
         return dir;
      }
   }
}
