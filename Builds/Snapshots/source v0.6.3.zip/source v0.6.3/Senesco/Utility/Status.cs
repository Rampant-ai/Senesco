﻿
namespace Senesco
{
   public enum Status
   {
      Failure = -1,
      NoResult = 0,
      Success = 1,
   }
}
