﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Threading;
using log4net;
using Senesco.Client;
using Senesco.Client.Communication;
using Senesco.Client.Events;
using Senesco.Client.Utility;
using Senesco.WPF.Windows.Config;
using Senesco.WPF.Windows.Dialog;

namespace Senesco.WPF.Windows.Main
{
   /// <summary>
   /// Interaction logic for ChatWindow.xaml
   /// </summary>
   public partial class ChatWindow : Window, ISenescoWindow
   {
      private static readonly ILog s_log = LogManager.GetLogger(typeof(ChatWindow));

      private readonly SenescoController m_controller = null;
      private UserListWindow m_userListWindow = null;
      private ActionQueue m_backgroundActions = new ActionQueue();

      private static List<Key> s_emoteKeys = new List<Key>()
      {
         Key.LeftAlt, Key.RightAlt,
         Key.LeftCtrl, Key.RightCtrl,
         Key.LeftShift, Key.RightShift
      };

      // GUI delegate definitions.
      public delegate void ChatDelegate(string text);
      public delegate void NoParamDelegate();
      public delegate void UserListDelegate(List<User> addList, List<User> removeList, bool delta);
      public delegate void ServerDelegate(Server server);
      public delegate void OneIntegerDelegate(int i);
      public delegate void OneStringDelegate(string str1);
      public delegate void TwoStringOneIntegerDelegate(string str1, string str2, int i);

      public ChatWindow()
      {
         // Initialize logging system.
         Log.InitLogging();

         // Start up this window.
         InitializeComponent();
         
         // Restore window position.
         WindowUtils.RestoreWindowPosition(this, null, WindowUtils.DefaultPosition.GlobalDefault);

         // Create and initialize the controller for all the internal logic.
         m_controller = new SenescoController();
         m_controller.ProgressUpdated += progressUpdated;
         m_controller.Connected += connected;
         m_controller.Disconnected += disconnected;
         m_controller.ChatReceived += chatReceived;
         m_controller.UserListUpdate += userListUpdate;
         m_controller.PmReceived += pmReceived;
         m_controller.UserInfoReceived += userInfoReceived;

         // Clear the window title initially.
         SetWindowTitle(null);

         // Synchronize the bookmark menu with the current bookmark files.
         UpdateBookmarks();

         // Process the command-line arguments.
         ProcessStartup();
      }

      private void ProcessStartup()
      {
         s_log.InfoFormat("Processing startup events.");

         try
         {
            string[] startupArgs = (string[])Application.Current.Properties["StartupArgs"];

            // Do nothing if no arguments.
            if (startupArgs == null || startupArgs.Length == 0)
               return;

            // Dump arguments if debug logging is enabled.
            if (s_log.IsDebugEnabled)
            {
               for (int i = 0; i < startupArgs.Length; i++)
                  s_log.DebugFormat("{0}: {1}", i, startupArgs[i]);
            }

            // Try to parse the first object as a bookmark.  Returns null upon failure.
            Server server = FileUtils.GetBookmark(new FileInfo(startupArgs[0]));

            // Connect to that server.
            if (server != null)
               InitiateConnect(server);
         }
         catch (Exception e)
         {
            s_log.ErrorFormat("Exception processing startup events: {0}", e.Message);
         }
      }

      private void Exit()
      {
         m_controller.Shutdown();
         if (Application.Current != null)
            Application.Current.Shutdown();
         Environment.Exit(0);
      }

      #region Window Management

      private void SetWindowTitle(string message)
      {
         // If no message given, just "Senesco".
         if (string.IsNullOrEmpty(message))
            this.Title = "Senesco";
         // Otherwise, suffix the message.
         else
            this.Title = string.Format("Senesco: {0}", message);
      }

      private void QuitHandler(object sender, EventArgs e)
      {
         Exit();
      }

      public void Window_SizeChanged(object sender, SizeChangedEventArgs e)
      {
         WindowUtils.SaveWindowPosition(this);
      }

      public void Window_LocationChanged(object sender, EventArgs e)
      {
         WindowUtils.SaveWindowPosition(this);
      }

      public void SaveWindowPosition()
      {
         ConfigSettings.UserSettings.ChatWindowLeft = this.Left;
         ConfigSettings.UserSettings.ChatWindowTop = this.Top;
         ConfigSettings.UserSettings.ChatWindowWidth = this.Width;
         ConfigSettings.UserSettings.ChatWindowHeight = this.Height;
      }

      public void RestoreWindowPosition()
      {
         this.Left = ConfigSettings.UserSettings.ChatWindowLeft;
         this.Top = ConfigSettings.UserSettings.ChatWindowTop;
         this.Width = ConfigSettings.UserSettings.ChatWindowWidth;
         this.Height = ConfigSettings.UserSettings.ChatWindowHeight;
      }

      #endregion

      #region Window Commands

      public static RoutedCommand ConnectCmd = new RoutedCommand();
      public static RoutedCommand DisconnectCmd = new RoutedCommand();
      public static RoutedCommand QuitCmd = new RoutedCommand();
      public static RoutedCommand UserConfigCmd = new RoutedCommand();
      public static RoutedCommand SoundConfigCmd = new RoutedCommand();
      public static RoutedCommand OpenLogsCmd = new RoutedCommand();
      public static RoutedCommand RevealLogsCmd = new RoutedCommand();
      public static RoutedCommand UserListCmd = new RoutedCommand();
      public static RoutedCommand AboutCmd = new RoutedCommand();
      public static RoutedCommand WebsiteCmd = new RoutedCommand();

      #endregion

      #region Bookmarks

      /// <summary>
      /// This method updates the bookmark menus.  Currently, there are two separate menus.
      /// One is for a quick-connect list, and the other is for picking which bookmark to use
      /// to use for the auto-login feature.
      /// </summary>
      public void UpdateBookmarks()
      {
         // Get the full list of bookmark names from the controller.
         List<string> bookmarkNames = m_controller.GetBookmarkNames();
         string autoConnectBookmark = m_controller.GetAutoConnectBookmark();

         // Clear the old list of bookmarks.
         s_log.InfoFormat("Clearing old bookmarks from root MenuItem {0}", m_connectRecent.Name);
         m_connectRecent.Items.Clear();
         m_autoConnect.Items.Clear();

         // If the list is no good or empty, disable the root menus.
         if (bookmarkNames == null || bookmarkNames.Count == 0)
         {
            m_connectRecent.IsEnabled = false;
            m_autoConnect.IsEnabled = false;
            return;
         }

         // Enable both root menus.
         m_connectRecent.IsEnabled = true;
         m_autoConnect.IsEnabled = true;

         // Create each bookmark as a new submenu item.
         s_log.InfoFormat("Updating {0} and {1} with bookmarks", m_connectRecent.Name, m_autoConnect.Name);
         int i = 1;
         foreach (string bookmarkName in bookmarkNames)
         {
            MenuItem mi = new MenuItem();
            mi.Name = String.Format("bookmark{0}", i);
            mi.Header = bookmarkName;
            mi.Click += bookmark_Click;
            m_connectRecent.Items.Add(mi);

            MenuItem ac = new MenuItem();
            ac.Name = String.Format("autoconnect{0}", i);
            ac.Header = bookmarkName;
            ac.Click += autoConnect_Click;
            ac.IsCheckable = true;
            ac.IsChecked = (autoConnectBookmark == bookmarkName); // Check the one that's currently set.
            m_autoConnect.Items.Add(ac);

            i++;
         }
      }

      private void autoConnect_Click(object sender, RoutedEventArgs e)
      {
         // Change the auto-connect bookmark to this one (if the selection has changed).
         MenuItem selected = sender as MenuItem;
         if (selected == null)
            return;
         string selectedBookmark = selected.Header as string;

         // If the user clicked the one that's already checked, then remove the auto-connect.
         if (selected.IsChecked == false)
            RegistryUtils.RemoveAutoConnectBookmark();
         else
         {
            // Set the user's new selection in the registry.
            RegistryUtils.SetAutoConnectBookmark(selectedBookmark);

            // Update the checks to reflect the new selection (like radio buttons).
            foreach (MenuItem mi in m_autoConnect.Items)
               mi.IsChecked = (selectedBookmark == mi.Header as string);
         }
      }

      #endregion

      #region Chat

      private void chatEntry_TextChanged(object sender, TextChangedEventArgs e)
      {
         // If the change is a single event with a newline, send the chat.
         TextBox textBox = sender as TextBox;

         // Get the last TextChange.
         TextChange lastChange = null;
         foreach (TextChange tc in e.Changes)
            lastChange = tc;

         // The last change must be an "add".
         if (lastChange.AddedLength <= 0)
            return;

         // Get the substring that was added for this TextChange.
         string addedText = textBox.Text.Substring(lastChange.Offset, lastChange.AddedLength);

         // If the added text is not a newline, do nothing.
         if (addedText != Environment.NewLine)
            return;

         // Remove this added newline before sending the text to the server.
         string textToSend = textBox.Text.Remove(lastChange.Offset, lastChange.AddedLength);

         // Clear the chat box.
         textBox.Text = string.Empty;

         // Is the keyboard modifier for emote being held down?
         bool emote = false;
         foreach (Key k in s_emoteKeys)
         {
            if (Keyboard.IsKeyDown(k))
               emote = true;
         }

         // Send the text to the server.
         m_backgroundActions.Add(() => m_controller.SendChat(textToSend, emote));
      }

      private void chatEntry_KeyDown(object sender, KeyEventArgs e)
      {
         //if (e.Key == Key.LeftAlt)
         //   m_emoteKeyHeld = true;

         //if (e.Key == Key.Return && e.IsRepeat == false)
         //{
         //   bool emote = Keyboard.IsKeyDown(Key.LeftCtrl);
         //   if (m_controller.SendChat(this.chatEntry.Text, emote) == Status.Success)
         //      this.chatEntry.Text = string.Empty;
         //}
      }

      private void chatReceived(object sender, ChatReceivedEventArgs e)
      {
         if (e != null)
         {
            Dispatcher.Invoke(new ChatDelegate(chatReceivedDelegate), e.Text);
         }
      }

      private void chatReceivedDelegate(string text)
      {
         // Make sure only one thread at a time adds text.
         lock (m_chatView)
         {
            m_chatView.AppendText(text);

            // If the user is at or lower than 80% of the total scrollback, that's
            // pretty near the bottom, so keep the chat scrolled all the way down.
            // This is how we achieve auto-scroll while still allowing the user to
            // scroll up while chat may be actively ongoing.

            // The total height scrollback is "ExtentHeight".  The lowest point
            // currently visible is "VerticalOffset" plus "ViewportHeight".
            if (m_chatView.VerticalOffset + m_chatView.ViewportHeight >= (0.8 * m_chatView.ExtentHeight))
               m_chatView.ScrollToEnd();
         }
      }

      private void chatView_MouseUp(object sender, MouseButtonEventArgs e)
      {
         // Look for URLs under the cursor position.
         TextPointer textPointer = m_chatView.CaretPosition;
         if (textPointer == null)
            return;
         Paragraph paragraph = textPointer.Paragraph;
         if (paragraph == null)
            return;
         if (paragraph.Inlines == null || paragraph.Inlines.Count == 0)
            return;
         Inline inline = paragraph.Inlines.FirstInline;
         if (inline == null)
            return;
         Run run = inline as Run;
         if (run == null)
            return;
         //m_chatEntry.Text = run.Text;
      }

      #endregion

      #region Chat Logs

      private void OpenLogsHandler(object sender, RoutedEventArgs e)
      {
         m_backgroundActions.Add(m_controller.OpenChatLog);
      }

      private void RevealLogsHandler(object sender, RoutedEventArgs e)
      {
         m_backgroundActions.Add(m_controller.ShowChatLogs);
      }

      #endregion

      #region User Info

      private void userInfoReceived(object sender, UserInfoEventArgs e)
      {
         if (e != null)
         {
            Dispatcher.Invoke(new OneStringDelegate(userInfoReceivedDelegate), e.UserInfo);
         }
      }

      private void userInfoReceivedDelegate(string userInfo)
      {
         new UserInfoWindow(this, userInfo).Show();
      }

      #endregion

      #region Private Message

      private void pmReceived(object sender, PrivateMsgEventArgs e)
      {
         if (e != null)
         {
            Dispatcher.Invoke(new TwoStringOneIntegerDelegate(pmReceivedDelegate), e.SendingNick, e.Message, e.SendingUserId);
         }
      }

      private void pmReceivedDelegate(string sendingNick, string message, int sendingUserId)
      {
         PmReceiveWindow pmWindow = new PmReceiveWindow(this, m_controller, sendingNick, sendingUserId, message);
         pmWindow.Show();
      }

      #endregion

      #region Connection Controls

      private void InitiateConnect(Server server)
      {
         if (server == null)
            return;

         m_backgroundActions.Add(() => InitiateConnectDelegate(server));
      }

      private Status InitiateConnectDelegate(Server server)
      {
         if (server == null)
            return Status.Failure;

         // Update the window title.
         Dispatcher.Invoke(new OneStringDelegate(SetWindowTitle), String.Format("Connecting to '{0}'...", server.ServerName));

         // Display the progress bar.
         Dispatcher.Invoke(new NoParamDelegate(ProgressBar_Show));

         // Connect to the server.
         Status result = m_controller.Connect(server);

         // Hide the progress bar when finished.
         Dispatcher.Invoke(new NoParamDelegate(ProgressBar_Hide));

         // Reset the window title if connecting failed.
         if (result != Status.Success)
         {
            Dispatcher.Invoke(new OneStringDelegate(SetWindowTitle), new object[1] { null });
         }

         return result;
      }

      private void connected(object sender, ConnectedEventArgs e)
      {
         Dispatcher.Invoke(new NoParamDelegate(connectedEvent));
      }

      private void connectedEvent()
      {
         // Update the window title with the connected server name.
         SetWindowTitle(m_controller.ConnectedServerName);

         // Request the user list to populate the user list window.
         m_controller.GetUserList();

         // Open the user list window if necessary.
         OpenUserListWindow();

         // Enable the "Disconnect" menu option since we're connected.
         m_disconnectMenu.IsEnabled = true;
      }

      private void progressUpdated(object sender, ProgressUpdatedEventArgs e)
      {
         Dispatcher.Invoke(new OneIntegerDelegate(progressUpdatedEvent), e.ProgressPercent);
      }

      private void progressUpdatedEvent(int percent)
      {
         // Update the progress bar.
         m_progressBar.Value = percent;
      }

      private void ProgressBar_Show()
      {
         // Display the progress bar.
         m_progressBar.Value = 0;
         m_progressBar.Visibility = Visibility.Visible;
      }

      private void ProgressBar_Hide()
      {
         // Hide the progress bar.
         m_progressBar.Value = 0;
         m_progressBar.Visibility = Visibility.Collapsed;
      }

      private void bookmark_Click(object sender, RoutedEventArgs e)
      {
         MenuItem bookmarkItem = sender as MenuItem;
         if (bookmarkItem == null)
         {
            s_log.ErrorFormat("Bad sender for bookmark_Click()!");
            return;
         }

         s_log.InfoFormat("Bookmark '{0}' was clicked from menu.", bookmarkItem.Header);

         Server server = m_controller.GetBookmark(bookmarkItem.Header as string);

         InitiateConnect(server);
      }

      private void ConnectHandler(object sender, RoutedEventArgs e)
      {
         // Display new connection window.
         ConnectWindow connectWindow = new ConnectWindow(this, m_controller);
         connectWindow.ShowDialog();

         // If the window did not configure a server, do nothing.
         if (connectWindow.ConfiguredServer == null)
         {
            s_log.InfoFormat("Connection window did not configure a server.");
            return;
         }

         InitiateConnect(connectWindow.ConfiguredServer);
      }

      private void DisconnectHandler(object sender, RoutedEventArgs e)
      {
         disconnectedEvent();
      }

      private void disconnected(object sender, EventArgs e)
      {
         Dispatcher.Invoke(new NoParamDelegate(disconnectedEvent));
      }

      private void disconnectedEvent()
      {
         // Disconnect from the server with the given reason.
         m_backgroundActions.Add(() => m_controller.Disconnect("User Quit."));

         // Clear the window title.
         SetWindowTitle(null);

         // Close and dispose the user list window.
         if (m_userListWindow != null)
         {
            m_userListWindow.Close();
            m_userListWindow = null;
         }
         
         // Disable the "Disconnect" menu option since no longer connected.
         m_disconnectMenu.IsEnabled = false;
      }

      #endregion

      #region Config Menu

      private void UserConfigHandler(object sender, RoutedEventArgs e)
      {
         // Display user config dialog.
         UserConfig config = new UserConfig(this, m_controller.LocalUser);
         config.ShowDialog();

         // If the user canceled, this will be null.
         User user = config.OutputUser;
         if (user == null)
            return;

         // If the user settings were changed, submit them to the server.
         if (m_controller.LocalUser.SettingsDiffer(user))
            m_controller.SetUserInfo(user);
      }

      private void SoundConfigHandler(object sender, RoutedEventArgs e)
      {
         // Display sound config dialog.
         SoundsConfig config = new SoundsConfig(this, m_controller.SoundController);
         config.ShowDialog();
      }
      
      #endregion

      #region User List

      private void OpenUserListWindow()
      {
         // Open a UserListWindow if one is not already opened.
         if (m_userListWindow == null)
         {
            m_userListWindow = new UserListWindow(this, m_controller);
            m_userListWindow.Closed += new EventHandler(userListWindowClosed);
            UserListWindowUpdate();
            m_userListWindow.Show();
         }
      }

      private void userListWindowClosed(object sender, EventArgs e)
      {
         // The window is closed, null the reference to it.
         m_userListWindow = null;
      }

      private void UserListHandler(object sender, RoutedEventArgs e)
      {
         // Open the window if necessary.
         OpenUserListWindow();

         // Activate and focus the window.
         m_userListWindow.Activate();
         m_userListWindow.Focus();
      }

      private void userListUpdate(object sender, UserListUpdateEventArgs e)
      {
         if (e != null)
         {
            Dispatcher.Invoke(new UserListDelegate(userListUpdateDelegate), e.AddList, e.RemoveList, e.Delta);
         }
      }

      private void userListUpdateDelegate(List<User> addList, List<User> removeList, bool delta)
      {
         UserListWindowUpdate();
      }

      private void UserListWindowUpdate()
      {
         // Update the existing window.
         if (m_userListWindow != null)
            m_userListWindow.RefreshUserList();
      }

      #endregion

      #region Help Menu

      private void AboutHandler(object sender, RoutedEventArgs e)
      {
         // Show the About window.
         AboutWindow aboutWindow = new AboutWindow(this);
         aboutWindow.Show();
      }

      private void WebsiteHandler(object sender, RoutedEventArgs e)
      {
         m_controller.LaunchWebsite();
      }

      #endregion
   }
}
