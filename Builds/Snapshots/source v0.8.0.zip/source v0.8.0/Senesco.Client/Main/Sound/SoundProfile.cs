﻿
using System.Collections.Generic;
using System.ComponentModel;
using Senesco.Client.Utility;

namespace Senesco.Client.Main.Sound
{
   /// <summary>
   /// Represents one complete set of sounds for the application.  There may be
   /// several instances of this class, so that the user can be provided with
   /// a selection of profiles to pick from, or create his own.
   /// </summary>
   public class SoundProfile : INotifyPropertyChanged
   {
      private string m_displayName = null;
      public string DisplayName
      {
         get { return m_displayName; }
         set
         {
            m_displayName = value;
            NotifyPropertyChanged("DisplayName");
         }
      }

      public List<SoundItem> SoundItems
      {
         get
         {
            List<SoundItem> soundItems = new List<SoundItem>();
            soundItems.Add(ChatClick);
            soundItems.Add(UserJoin);
            soundItems.Add(UserPart);
            soundItems.Add(PmReceived);
            soundItems.Add(PmSent);
            soundItems.Add(Connected);
            soundItems.Add(Disconnected);
            return soundItems;
         }
      }

      private SoundItem m_chatClick = new SoundItem(SoundEffect.ChatClick, "Chat Received");
      public SoundItem ChatClick
      {
         get { return m_chatClick; }
         set { m_chatClick = value; }
      }

      private SoundItem m_userJoin = new SoundItem(SoundEffect.UserJoin, "User Joined");
      public SoundItem UserJoin
      {
         get { return m_userJoin; }
         set { m_userJoin = value; }
      }

      private SoundItem m_userPart = new SoundItem(SoundEffect.UserPart, "User Parted");
      public SoundItem UserPart
      {
         get { return m_userPart; }
         set { m_userPart = value; }
      }

      private SoundItem m_pmReceived = new SoundItem(SoundEffect.PmReceived, "PM Received");
      public SoundItem PmReceived
      {
         get { return m_pmReceived; }
         set { m_pmReceived = value; }
      }

      private SoundItem m_pmSent = new SoundItem(SoundEffect.PmSent, "PM Sent");
      public SoundItem PmSent
      {
         get { return m_pmSent; }
         set { m_pmSent = value; }
      }

      private SoundItem m_connected = new SoundItem(SoundEffect.Connected, "Connected");
      public SoundItem Connected
      {
         get { return m_connected; }
         set { m_connected = value; }
      }

      private SoundItem m_disconnected = new SoundItem(SoundEffect.Disconnected, "Disconnected");
      public SoundItem Disconnected
      {
         get { return m_disconnected; }
         set { m_disconnected = value; }
      }

      /// <summary>
      /// Helper method to load all loaded sounds.
      /// </summary>
      public void SubmitAll()
      {
         //TODO: better analysis on the threading issues with this.
         SoundUtils.ClearSounds();

         foreach (SoundItem soundItem in SoundItems)
         {
            soundItem.Submit();
         }
      }

      #region INotifyPropertyChanged

      public event PropertyChangedEventHandler PropertyChanged;

      private void NotifyPropertyChanged(string info)
      {
         if (PropertyChanged != null)
            PropertyChanged(this, new PropertyChangedEventArgs(info));
      }

      #endregion
   }
}
