﻿
namespace Senesco.ObjectData
{
   public abstract class IHotlineObjectData
   {
      public abstract byte[] GetBytes();
   }
}
