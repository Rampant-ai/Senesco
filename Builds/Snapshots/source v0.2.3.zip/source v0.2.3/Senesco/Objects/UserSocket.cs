﻿using Senesco.ObjectData;
using Senesco.Utility;

namespace Senesco.Objects
{
   class UserSocket : HotlineObject
   {
      public Number Value;

      /// <summary>
      /// Default creator for the ObjectFactory to use.
      /// </summary>
      public UserSocket()
      { }

      public UserSocket(int userSocket)
      {
         Value = new Number(userSocket);
         this.ObjectDataList.Add(Value);
      }

      internal override void ParseBytes(byte[] objectData)
      {
         int index = 0;
         int userSocket = DataUtils.ReadNumber(objectData, ref index);

         Value = new Number(userSocket);
         this.ObjectDataList.Add(Value);
      }
   }
}
