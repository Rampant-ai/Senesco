﻿using System;
using log4net;

namespace Senesco
{
   class User
   {
      private static readonly ILog s_log = LogManager.GetLogger(typeof(User));

      public string Username;
      public int UserId;
      public int IconId;
      public uint Flags;


   }
}
