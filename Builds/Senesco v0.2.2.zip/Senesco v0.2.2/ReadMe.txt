
Senesco
v. To grow old, to grow aged, to mature, wear out. 

-----------------------------------------------

Who says Hotline is old, aged, matured, or worn out?

...Oh, right.  Everybody.



Future Planned Features
-----------------------
-Add chat logger.
-Hook up auto-reconnect system.
-Add user list display.
-Add chat-prefix system for command entry (eg. /me says hi).
-Add get-user-info system from user list.
-Port to win32 console.
-Port to other platforms using Mono.
-Port to other GUI's using Mono by ditching WPF.


Known Issues
------------
-Return key doesn't register when alt is held down (need to change input style drastically).
-There's no way to remove a saved bookmark except file the .sbm file and delete it.


