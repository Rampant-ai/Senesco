
Senesco
v. To grow old, to grow aged, to mature, wear out. 

-----------------------------------------------

Who says Hotline is old, aged, matured, or worn out?

...Oh, right.  Everybody.



Future Planned Features
-----------------------
-Opening an ".sbm" bookmark should launch Senesco and connect to that server.
-Hook up auto-reconnect system.

-Improve chat text display (hyperlinks, etc).
-Add chat-prefix system for command entry (eg. /me says hi).

-Improve user list display (icons, operations, etc).
-Add get-user-info system from user list.
-User-to-user (private) messaging.

-Port to win32 console.
-Port to other platforms using Mono.
-Port to other GUI's using Mono by ditching WPF.

-Make use of the "Server Name" transaction response.


Known Issues
------------
-Return key doesn't register when alt is held down (need to change input style drastically).
-There's no way to remove a saved bookmark except file the .sbm file and delete it.
-Bookmarks are not encoded, so your password is stored in plaintext (if you know where to look).
-Sizing chat window super small can screw up the division between chat view and chat entry box.


Features That Probably Won't Be Added
-------------------------------------
-News
-Files
-Agreement (unless needed?)
-Trackers
