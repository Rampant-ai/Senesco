
Senesco
v. To grow old, to grow aged, to mature, wear out. 

-----------------------------------------------

Who says Hotline is old, aged, matured, or worn out?

...Oh, right.  Everybody.



Future Planned Features
-----------------------
-Register .sbm with Windows on startup (and/or install).
-Hook up auto-reconnect system.

-Improve user list display (icons, operations, etc).
-Add get-user-info system from user list.
-User-to-user (private) messaging.

-Improve chat text display (hyperlinks, etc).
-Add chat-prefix system for command entry (eg. /me says hi).

-Port to win32 console.
-Port to other platforms using Mono.
-Port to other GUI's using Mono by ditching WPF.

-GUI control to show chat log.
-Remove bookmarks via GUI.


Known Issues
------------
-Most GUI operations block since they run in the foreground.
-Window positions not persisted (test on multi-monitor setups).
-Return key doesn't register when alt is held down (need to change input style drastically).
-Bookmarks are not encoded, so your password is stored in plaintext (if you know where to look).
-Sizing chat window super small can screw up the division between chat view and chat entry box.


Features That Probably Won't Be Added
-------------------------------------
-News
-Files
-Agreement
-Trackers
